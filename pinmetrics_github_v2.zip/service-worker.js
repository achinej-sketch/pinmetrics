// PinMetrics Pro - Service Worker v2.1

console.log('PinMetrics Pro - Service Worker loaded');

chrome.runtime.onInstalled.addListener((details) => {
  console.log('Extension installed:', details.reason);
});

// Injection du content script sur Pinterest
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.url || !tab.url.includes('pinterest')) return;

  const excluded = ['/business/hub/', '/business/catalogs/', 'ads.pinterest.com',
                    'analytics.pinterest.com', 'trends.pinterest.com', '/settings/'];
  if (excluded.some(p => tab.url.includes(p))) return;

  chrome.scripting.insertCSS({ target: { tabId }, files: ['styles.css'] }).catch(() => {});
  chrome.scripting.executeScript({ target: { tabId }, files: ['content-script.js'] }).catch(() => {});
});

// ── Message handler ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // Sauvegarde stats pin
  if (message.action === 'saveStats') {
    const { pinId, stats } = message;
    chrome.storage.local.get(['pinsData'], (result) => {
      const pinsData = result.pinsData || {};
      pinsData[pinId] = stats;
      chrome.storage.local.set({ pinsData }, () => sendResponse({ success: true }));
    });
    return true;
  }

  // Récupère stats
  if (message.action === 'getStats') {
    chrome.storage.local.get(['pinsData'], (result) => {
      sendResponse({ stats: result.pinsData || {} });
    });
    return true;
  }

  // ── Fetch Pinterest Trends (via onglet trends.pinterest.com pour les cookies) ─
  if (message.action === 'fetchTrendsMetrics' || message.action === 'fetchTopTrends') {
    const { url } = message;

    // Chercher un onglet trends.pinterest.com déjà ouvert
    chrome.tabs.query({ url: 'https://trends.pinterest.com/*' }, (tabs) => {
      if (tabs && tabs.length > 0) {
        // Exécuter le fetch dans l'onglet qui a les cookies
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: async (fetchUrl) => {
            try {
              const r = await fetch(fetchUrl, {
                method: 'GET',
                credentials: 'include',
                headers: { 'Accept': '*/*', 'X-New-Site': 'true' }
              });
              if (!r.ok) return { success: false, error: 'HTTP ' + r.status };
              const data = await r.json();
              return { success: true, data };
            } catch(e) {
              return { success: false, error: e.message };
            }
          },
          args: [url]
        }, (results) => {
          if (chrome.runtime.lastError || !results || !results[0]) {
            sendResponse({ success: false, error: 'Erreur injection script' });
          } else {
            sendResponse(results[0].result);
          }
        });
      } else {
        // Ouvrir un onglet trends en arrière-plan
        chrome.tabs.create({ url: 'https://trends.pinterest.com/', active: false }, (tab) => {
          // Attendre que la page charge
          const listener = (tabId, changeInfo) => {
            if (tabId === tab.id && changeInfo.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: async (fetchUrl) => {
                  try {
                    const r = await fetch(fetchUrl, {
                      method: 'GET',
                      credentials: 'include',
                      headers: { 'Accept': '*/*', 'X-New-Site': 'true' }
                    });
                    if (!r.ok) return { success: false, error: 'HTTP ' + r.status };
                    const data = await r.json();
                    return { success: true, data };
                  } catch(e) {
                    return { success: false, error: e.message };
                  }
                },
                args: [url]
              }, (results) => {
                if (chrome.runtime.lastError || !results || !results[0]) {
                  sendResponse({ success: false, error: 'Erreur injection script' });
                } else {
                  sendResponse(results[0].result);
                }
                // Fermer l'onglet après
                chrome.tabs.remove(tab.id);
              });
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }
    });
    return true;
  }

  // ── Analyse texte image via service worker (contourne le blocage CORS canvas) ──
  // Le SW fetch l'image sans CORS, puis analyse les pixels via OffscreenCanvas
  if (message.action === 'analyzeImageForText') {
    const { url } = message;
    (async () => {
      try {
        const resp = await fetch(url, { credentials: 'omit' });
        if (!resp.ok) { sendResponse({ result: 'unknown' }); return; }
        const blob = await resp.blob();
        const bitmap = await createImageBitmap(blob);

        const W = bitmap.width, H = bitmap.height;
        const scale = Math.min(1, 200 / Math.max(W, H));
        const w = Math.max(1, Math.round(W * scale));
        const h = Math.max(1, Math.round(H * scale));

        const oc  = new OffscreenCanvas(w, h);
        const ctx = oc.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(bitmap, 0, 0, w, h);
        bitmap.close();

        const raw  = ctx.getImageData(0, 0, w, h).data;
        const luma = new Float32Array(w * h);
        for (let i = 0; i < w * h; i++)
          luma[i] = 0.299 * raw[i*4] + 0.587 * raw[i*4+1] + 0.114 * raw[i*4+2];

        // Gradient Sobel — seuil 50 : les bords de gros titres dépassent largement
        const EDGE_T  = 50;
        const edgeMap = new Uint8Array(w * h);
        for (let y = 1; y < h - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const i = y * w + x;
            const gH = Math.abs(luma[i+1] - luma[i-1]);
            const gV = Math.abs(luma[i+w] - luma[i-w]);
            edgeMap[i] = (gH > EDGE_T || gV > EDGE_T) ? 1 : 0;
          }
        }

        // Bande glissante (12% de hauteur) : densité max de bords dans une bande
        const BAND_H    = Math.max(3, Math.floor(h * 0.12));
        const BAND_STEP = Math.max(1, Math.floor(BAND_H / 2));
        let maxDens = 0;
        for (let sy = 0; sy <= h - BAND_H; sy += BAND_STEP) {
          let count = 0;
          for (let y = sy; y < sy + BAND_H; y++)
            for (let x = 0; x < w; x++) count += edgeMap[y * w + x];
          const d = count / (BAND_H * w);
          if (d > maxDens) maxDens = d;
        }

        sendResponse({ result: maxDens > 0.16 ? 'text' : 'image', score: maxDens });
      } catch(e) {
        sendResponse({ result: 'unknown', error: e.message });
      }
    })();
    return true; // async
  }

  // ── Téléchargement d'image via le service worker ──────────────────────────
  // Le SW peut fetcher les images CDN Pinterest (host_permissions) sans CORS
  if (message.action === 'fetchImageAsBase64') {
    const { url } = message;
    fetch(url, { credentials: 'omit' })
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.arrayBuffer();
      })
      .then(buf => {
        // Convertir en base64 pour transmettre via message
        const bytes = new Uint8Array(buf);
        let binary = '';
        // Traitement par chunks pour éviter stack overflow sur images lourdes
        const CHUNK = 8192;
        for (let i = 0; i < bytes.length; i += CHUNK) {
          binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
        }
        const base64 = btoa(binary);
        const ext = (url.split('.').pop().split('?')[0] || 'jpg')
                      .toLowerCase().replace(/[^a-z]/g, '') || 'jpg';
        sendResponse({ success: true, base64, ext, size: buf.byteLength });
      })
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true; // async
  }

});

console.log('PinMetrics Pro - Service Worker initialized');
