// PinMetrics Pro — Dashboard v3.0

(function() {
  'use strict';

  // ── State pins ──────────────────────────────────────────────────────────────
  var allPins    = [];
  var filtered   = [];
  var selected   = new Set();
  var sortCol    = 'saves';
  var sortDir    = 'desc';
  var currentPage= 1;
  var PAGE_SIZE  = 50;
  var viewMode   = 'table';
  var csvMode    = 'blog';

  // ── State trends ─────────────────────────────────────────────────────────────
  var allTrends    = [];
  var filteredTrends = [];
  var trendsFilter = 'all';
  var trendsLoaded = false;

  // ══════════════════════════════════════════════════════════════════════════════
  // NAVIGATION ONGLETS
  // ══════════════════════════════════════════════════════════════════════════════
  document.querySelectorAll('.nav-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.nav-btn').forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      var tab = btn.dataset.tab;
      document.getElementById('tabPins').style.display      = tab === 'pins'      ? '' : 'none';
      document.getElementById('tabPinmaker').style.display  = tab === 'pinmaker'  ? '' : 'none';
      document.getElementById('tabTrends').style.display    = tab === 'trends'    ? '' : 'none';
      if (tab === 'trends' && !trendsLoaded) loadTrends();
      if (tab === 'pinmaker' && !window._pmInited) { window._pmInited = true; initPinMaker(); }
    });
  });

  // ══════════════════════════════════════════════════════════════════════════════
  // ONGLET PINS — LOAD
  // ══════════════════════════════════════════════════════════════════════════════
  function loadPins() {
    chrome.storage.local.get(null, function(items) {
      var map = {};
      var toMigrate = {};
      for (var k in items) {
        if (!items.hasOwnProperty(k)) continue;
        var v = items[k];
        if (!v || typeof v !== 'object') continue;
        if (k.startsWith('pin_') && v.id) {
          map[v.id] = normalizePin(v.id, v);
        } else if (k === 'pinsData') {
          for (var pid in v) {
            if (!map[pid] && v[pid]) {
              var n = normalizePin(pid, v[pid]);
              map[pid] = n;
              toMigrate['pin_' + pid] = n;
            }
          }
        }
      }
      if (Object.keys(toMigrate).length > 0) {
        chrome.storage.local.set(toMigrate);
      }
      allPins = Object.values(map);
      apply();
    });
  }

  function normalizePin(pinId, v) {
    var saves = v.saves || 0;
    var days = v.createdAt ? (Date.now() - new Date(v.createdAt).getTime()) / 86400000 : 0;
    var viral = v.viralScore || (days > 0 ? Math.round(saves / days * 10) / 10 : 0);
    return {
      id: String(v.id || pinId),
      title: v.title || '',
      description: v.description || '',
      saves: saves,
      comments: v.comments || 0,
      shares: v.shares || 0,
      reactions: v.reactions || 0,
      createdAt: v.createdAt || null,
      viralScore: viral,
      isHot: v.isHot || viral >= 20,
      isEarly: v.isEarly || false,
      aspectRatio: v.aspectRatio || null,
      created: v.created || '',
      imageUrl: v.imageUrl || '',
      imageUrlOrig: v.imageUrlOrig || v.imageUrl || '',
      pinUrl: v.pinUrl || ('https://www.pinterest.com/pin/' + pinId + '/'),
      boardName: v.boardName || '',
      boardUrl: v.boardUrl || '',
      pinner: v.pinner || '',
      pinnerUrl: v.pinnerUrl || '',
      bookmarked: v.bookmarked || false,
      hasText: v.hasText || null,
      timestamp: v.timestamp || Date.now()
    };
  }

  // ── Filter + sort ────────────────────────────────────────────────────────────
  function apply() {
    var q        = (document.getElementById('searchInput').value || '').toLowerCase();
    var period   = document.getElementById('periodFilter').value;
    var ratio    = document.getElementById('ratioFilter').value;
    var minSaves = parseFloat(document.getElementById('minSaves').value) || 0;
    var minViral = parseFloat(document.getElementById('minViral').value) || 0;
    var hotOnly  = document.getElementById('hotOnly').checked;
    var earlyOnly= document.getElementById('earlyOnly').checked;
    var bkOnly   = document.getElementById('bookmarkedOnly').checked;
    var textFilter = document.getElementById('textFilter') ? document.getElementById('textFilter').value : 'all';
    var cutoff   = period !== 'all' ? Date.now() - parseInt(period) * 86400000 : 0;

    filtered = allPins.filter(function(p) {
      if (q && ![(p.title||''),(p.boardName||''),(p.pinner||'')].some(function(s){return s.toLowerCase().includes(q);})) return false;
      if (cutoff && p.createdAt && new Date(p.createdAt).getTime() > 0 && new Date(p.createdAt).getTime() < cutoff) return false;
      if (ratio !== 'all' && p.aspectRatio && p.aspectRatio !== ratio) return false;
      if (minSaves > 0 && (p.saves||0) < minSaves) return false;
      if (minViral > 0 && (p.viralScore||0) < minViral) return false;
      if (hotOnly   && !p.isHot)    return false;
      if (earlyOnly && !p.isEarly)  return false;
      if (bkOnly    && !p.bookmarked) return false;
      if (textFilter === 'text'  && p.hasText !== 'text')  return false;
      if (textFilter === 'image' && p.hasText !== 'image') return false;
      return true;
    });

    filtered.sort(function(a, b) {
      if (sortCol === 'title') {
        var va = (a.title||'').toLowerCase(), vb = (b.title||'').toLowerCase();
        return sortDir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
      }
      var va = sortCol === 'createdAt' ? (a.createdAt ? new Date(a.createdAt).getTime() : 0) : (a[sortCol]||0);
      var vb = sortCol === 'createdAt' ? (b.createdAt ? new Date(b.createdAt).getTime() : 0) : (b[sortCol]||0);
      return sortDir === 'asc' ? va - vb : vb - va;
    });

    currentPage = 1;
    updateKPIs();
    render();
    updateSelCount();
  }

  // ── KPIs ─────────────────────────────────────────────────────────────────────
  function updateKPIs() {
    set('kTotalPins',     fmt(allPins.length));
    set('kTotalSaves',    fmt(allPins.reduce(function(s,p){return s+(p.saves||0);},0)));
    set('kTotalComments', fmt(allPins.reduce(function(s,p){return s+(p.comments||0);},0)));
    set('kTotalReactions',fmt(allPins.reduce(function(s,p){return s+(p.reactions||0);},0)));
    var avg = allPins.length ? (allPins.reduce(function(s,p){return s+(p.viralScore||0);},0)/allPins.length).toFixed(1) : 0;
    set('kAvgViral', avg);
  }

  // ── Render ───────────────────────────────────────────────────────────────────
  function render() {
    var total = filtered.length;
    var totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    currentPage = Math.min(currentPage, totalPages);
    var start = (currentPage - 1) * PAGE_SIZE;
    var page  = filtered.slice(start, start + PAGE_SIZE);
    set('viewInfo', total + ' pin' + (total > 1 ? 's' : '') + ' filtrés sur ' + allPins.length + ' collectés');
    if (viewMode === 'table') renderTable(page);
    else renderGrid(page);
    renderPagination(total, totalPages);
    updateSortHeaders();
    syncHeaderCheck();
  }

  function renderTable(page) {
    var tbody = document.getElementById('tableBody');
    var empty = document.getElementById('emptyState');
    if (!allPins.length) { tbody.innerHTML = ''; empty.style.display = 'block'; return; }
    empty.style.display = 'none';

    tbody.innerHTML = page.map(function(p) {
      var isSel = selected.has(p.id);
      return '<tr class="' + (isSel ? 'selected' : '') + '">' +
        '<td class="td-check"><input type="checkbox" class="row-check" data-id="' + p.id + '"' + (isSel ? ' checked' : '') + '></td>' +
        '<td class="td-img"><a href="' + (p.pinUrl||'#') + '" target="_blank">' +
          (p.imageUrl ? '<img src="' + p.imageUrl + '" alt="" loading="lazy" onerror="this.parentNode.innerHTML=\'<div class=td-img-ph></div>\'">' : '<div class="td-img-ph"></div>') +
        '</a></td>' +
        '<td class="td-title">' +
          (p.isHot ? '<span class="badge-hot">Hot</span><br>' : p.isEarly ? '<span class="badge-early">Early</span><br>' : '') +
          '<a href="' + (p.pinUrl||'#') + '" target="_blank">' + esc(p.title||'(sans titre)') + '</a>' +
        '</td>' +
        '<td class="td-num">' + fmt(p.saves) + '</td>' +
        '<td class="td-num">' + fmt(p.comments) + '</td>' +
        '<td class="td-num">' + fmt(p.reactions) + '</td>' +
        '<td class="td-viral">' + (p.viralScore > 0 ? p.viralScore.toFixed(1) + '/j' : '—') + '</td>' +
        '<td style="font-size:11px;color:#9ca3af;">' + fmtDate(p.createdAt) + '</td>' +
        '<td style="font-size:11px;max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' +
          (p.boardName ? '<a href="' + (p.boardUrl||'#') + '" target="_blank" style="color:#6b7280;text-decoration:none;">' + esc(p.boardName) + '</a>' : '—') +
        '</td>' +
        '<td><div class="td-action">' +
          '<button class="act-btn ' + (p.bookmarked ? 'bk-active' : '') + '" data-id="' + p.id + '" data-action="bk" title="' + (p.bookmarked?'Retirer':'Bookmark') + '">' + (p.bookmarked?'🔖':'🏷') + '</button>' +
          '<a href="' + (p.pinUrl||'#') + '" target="_blank" class="act-btn" title="Ouvrir">↗</a>' +
          (p.imageUrl ? '<a href="' + p.imageUrl + '" download target="_blank" class="act-btn" title="Telecharger">⬇</a>' : '') +
        '</div></td>' +
      '</tr>';
    }).join('');

    tbody.querySelectorAll('.row-check').forEach(function(cb) {
      cb.addEventListener('change', function() {
        var id = cb.dataset.id;
        if (cb.checked) selected.add(id); else selected.delete(id);
        cb.closest('tr').classList.toggle('selected', cb.checked);
        updateSelCount(); syncHeaderCheck();
      });
    });
    tbody.querySelectorAll('[data-action="bk"]').forEach(function(btn) {
      btn.addEventListener('click', function() { toggleBookmark(btn.dataset.id, btn); });
    });
  }

  function renderGrid(page) {
    var grid = document.getElementById('pinGrid');
    grid.innerHTML = page.map(function(p) {
      var isSel = selected.has(p.id);
      return '<div class="pin-card ' + (isSel ? 'selected' : '') + '" data-id="' + p.id + '">' +
        '<div class="pin-card-check"><input type="checkbox" class="grid-check" data-id="' + p.id + '"' + (isSel ? ' checked' : '') + '></div>' +
        '<div class="pin-card-img pin-card-img-selectable">' +
          (p.imageUrl ? '<img src="' + p.imageUrl + '" alt="" loading="lazy" style="cursor:pointer;">' : '') +
          '<div class="card-badge">' + (p.isHot ? '<span class="badge-hot">Hot</span>' : p.isEarly ? '<span class="badge-early">Early</span>' : '') + '</div>' +
        '</div>' +
        (p.pinUrl ? '<div class="pin-card-viewlink"><a href="' + p.pinUrl + '" target="_blank" onclick="event.stopPropagation();">voir le pin ↗</a></div>' : '') +
        '<div class="pin-card-body">' +
          '<div class="pin-card-title"><a href="' + (p.pinUrl||'#') + '" target="_blank">' + esc(p.title||'(sans titre)') + '</a></div>' +
          '<div class="pin-card-stats">' +
            '<div class="card-stat">💾 ' + fmt(p.saves) + '</div>' +
            (p.viralScore > 0 ? '<div class="card-stat card-viral">🚀 ' + p.viralScore.toFixed(1) + '/j</div>' : '') +
            '<div class="card-stat" style="color:#9ca3af;font-size:10px;">' + fmtDate(p.createdAt) + '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');

    grid.querySelectorAll('.grid-check').forEach(function(cb) {
      cb.addEventListener('change', function() {
        var id = cb.dataset.id;
        if (cb.checked) selected.add(id); else selected.delete(id);
        cb.closest('.pin-card').classList.toggle('selected', cb.checked);
        updateSelCount(); syncHeaderCheck();
      });
    });

    // Clic sur l'image → toggle sélection (comme Pin Maker)
    grid.querySelectorAll('.pin-card-img-selectable').forEach(function(imgDiv) {
      imgDiv.addEventListener('click', function() {
        var card = imgDiv.closest('.pin-card');
        var id = card.dataset.id;
        var cb = card.querySelector('.grid-check');
        if (selected.has(id)) {
          selected.delete(id);
          cb.checked = false;
          card.classList.remove('selected');
        } else {
          selected.add(id);
          cb.checked = true;
          card.classList.add('selected');
        }
        updateSelCount(); syncHeaderCheck();
      });
    });
  }

  function updateSelCount() { set('selCount', selected.size + ' selectionne' + (selected.size > 1 ? 's' : '')); }

  function syncHeaderCheck() {
    var pageIds = getCurrentPageIds();
    var hc = document.getElementById('headerCheck');
    if (hc) { hc.checked = pageIds.length > 0 && pageIds.every(function(id){return selected.has(id);}); hc.indeterminate = !hc.checked && pageIds.some(function(id){return selected.has(id);}); }
    var sc = document.getElementById('selectAll');
    if (sc) sc.checked = allPins.length > 0 && selected.size === filtered.length;
  }

  function getCurrentPageIds() {
    var start = (currentPage - 1) * PAGE_SIZE;
    return filtered.slice(start, start + PAGE_SIZE).map(function(p){return p.id;});
  }

  function getPinsToExport() {
    return selected.size === 0 ? filtered : filtered.filter(function(p){return selected.has(p.id);});
  }

  // ── Pagination ───────────────────────────────────────────────────────────────
  function renderPagination(total, totalPages) {
    var pag = document.getElementById('pagination');
    if (totalPages <= 1) { pag.innerHTML = ''; return; }
    var range = getRange(currentPage, totalPages);
    var html = '<button class="pg-btn" ' + (currentPage <= 1 ? 'disabled' : '') + ' id="pgPrev">‹</button>';
    range.forEach(function(p) {
      if (p === '…') html += '<span class="pg-info">…</span>';
      else html += '<button class="pg-btn ' + (p === currentPage ? 'active' : '') + '" data-pg="' + p + '">' + p + '</button>';
    });
    html += '<button class="pg-btn" ' + (currentPage >= totalPages ? 'disabled' : '') + ' id="pgNext">›</button>';
    pag.innerHTML = html;
    var prev = pag.querySelector('#pgPrev'); if (prev) prev.addEventListener('click', function(){currentPage--;render();});
    var next = pag.querySelector('#pgNext'); if (next) next.addEventListener('click', function(){currentPage++;render();});
    pag.querySelectorAll('[data-pg]').forEach(function(b){b.addEventListener('click', function(){currentPage=parseInt(b.dataset.pg);render();});});
  }

  function getRange(cur, tot) {
    if (tot <= 7) { var r=[]; for(var i=1;i<=tot;i++) r.push(i); return r; }
    if (cur <= 4) return [1,2,3,4,5,'…',tot];
    if (cur >= tot-3) return [1,'…',tot-4,tot-3,tot-2,tot-1,tot];
    return [1,'…',cur-1,cur,cur+1,'…',tot];
  }

  function updateSortHeaders() {
    document.querySelectorAll('th.sortable').forEach(function(th) {
      th.classList.remove('sort-asc','sort-desc');
      if (th.dataset.col === sortCol) th.classList.add(sortDir === 'asc' ? 'sort-asc' : 'sort-desc');
    });
  }

  // ── Bookmark ─────────────────────────────────────────────────────────────────
  function toggleBookmark(pinId, btn) {
    var key = 'pin_' + pinId;
    chrome.storage.local.get(key, function(r) {
      var d = r[key]; if (!d) return;
      d.bookmarked = !d.bookmarked;
      var obj = {}; obj[key] = d;
      chrome.storage.local.set(obj);
      var idx = allPins.findIndex(function(p){return p.id===pinId;});
      if (idx >= 0) allPins[idx].bookmarked = d.bookmarked;
      btn.textContent = d.bookmarked ? '🔖' : '🏷';
      btn.classList.toggle('bk-active', d.bookmarked);
      showToast(d.bookmarked ? 'Bookmarke' : 'Retire');
    });
  }

  // ── Export CSV ───────────────────────────────────────────────────────────────
  function csvEsc(v) {
    var s = String(v == null ? '' : v);
    if (s.includes('"') || s.includes(',') || s.includes('\n') || s.includes('\r')) {
      return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
  }

  function buildUtmLink(url, idx) {
    try {
      var u = new URL(url);
      u.searchParams.set('utm_source','pinterest');
      u.searchParams.set('utm_medium','bulk');
      u.searchParams.set('utm_content','pin'+String(idx).padStart(2,'0'));
      return u.toString();
    } catch(e) {
      var sep = url.includes('?') ? '&' : '?';
      return url + sep + 'utm_source=pinterest&utm_medium=bulk&utm_content=pin' + String(idx).padStart(2,'0');
    }
  }

  function exportCSV() {
    var pins = getPinsToExport();
    if (!pins.length) { showToast('Aucun pin a exporter'); return; }
    if (csvMode === 'blog') exportCSVBlog(pins);
    else exportCSVAff(pins);
  }

  function exportCSVBlog(pins) {
    var board  = (document.getElementById('csvBoard').value||'').trim();
    var dest   = (document.getElementById('csvDestUrl').value||'').trim();
    var tBase  = (document.getElementById('csvTitleBase').value||'').trim();
    var useUtm = document.getElementById('csvUtm').checked;
    var pubDate= (document.getElementById('csvPublishDate').value||'').trim();
    if (!board) { showToast('Renseigne le Board'); document.getElementById('csvBoard').focus(); return; }
    if (!dest)  { showToast("Renseigne l'URL de destination"); document.getElementById('csvDestUrl').focus(); return; }
    var hdr = ['Title','Media URL','Pinterest board','Description','Link'];
    if (pubDate) hdr.push('Publish date');
    var rows = pins.filter(function(p){return p.imageUrl;}).map(function(p,i) {
      var n = i+1, base = tBase||p.title||'Pin';
      var title = pins.length > 1 ? base+' ('+n+')' : base;
      var link = useUtm ? buildUtmLink(dest,n) : dest;
      var row = [csvEsc(title),csvEsc(p.imageUrl),csvEsc(board),csvEsc(p.description||''),csvEsc(link)];
      if (pubDate) row.push(csvEsc(pubDate));
      return row.join(',');
    });
    if (!rows.length) { showToast('Aucun pin avec image'); return; }
    downloadText('\uFEFF'+[hdr.join(',')].concat(rows).join('\n'), 'pinterest-blog-'+ts()+'.csv', 'text/csv;charset=utf-8');
    showToast('CSV Blog : '+rows.length+' pins exportes');
  }

  function exportCSVAff(pins) {
    var tag   = (document.getElementById('affTag').value||'').trim();
    var lien  = (document.getElementById('affLien').value||'').trim();
    var board = (document.getElementById('affBoard').value||'').trim();
    var desc  = (document.getElementById('affDesc').value||'').trim();
    var hash  = (document.getElementById('affHashtags').value||'').trim();
    var useUtm= document.getElementById('affUtm').checked;
    if (!board) { showToast('Renseigne le Board'); document.getElementById('affBoard').focus(); return; }
    if (!lien)  { showToast('Renseigne le lien Amazon'); document.getElementById('affLien').focus(); return; }
    if (!desc)  { showToast('Renseigne la description'); document.getElementById('affDesc').focus(); return; }
    if (!desc.includes('#ad')) { document.getElementById('adWarn').style.display=''; showToast('#ad obligatoire dans la description'); return; }
    document.getElementById('adWarn').style.display='none';
    var descFull = (desc + (hash ? ' '+hash : '')).trim();
    var hdr = ['Title','Media URL','Pinterest board','Description','Link'];
    var titleBase = (document.getElementById('affTitleBase')?.value || '').trim();

    // Rendre les titres uniques (Pinterest refuse les doublons)
    var seenTitles = {};
    var rows = pins.filter(function(p){return p.imageUrl;}).map(function(p,i) {
      var n = i+1;
      var url = lien;
      // Si c'est un lien raccourci amzn.to, on ne touche pas à l'URL
      var isShortLink = lien.includes('amzn.to') || lien.includes('amzn.com/');
      if (!isShortLink) {
        try {
          var u = new URL(lien);
          u.searchParams.set('tag', tag);
          if (useUtm) {
            u.searchParams.set('utm_source','pinterest');
            u.searchParams.set('utm_medium','bulk');
            u.searchParams.set('utm_content','pin'+String(n).padStart(2,'0'));
          }
          url = u.toString();
        } catch(e) {}
      }
      // Titre : priorité au titre de base saisi, sinon titre du pin, sinon "Pin N"
      var baseTitle = titleBase
        ? (pins.length > 1 ? titleBase + ' ' + n : titleBase)
        : (p.title || ('Pin ' + n));
      baseTitle = baseTitle.slice(0, 90);
      var title = baseTitle;
      if (seenTitles[title.toLowerCase()]) {
        title = baseTitle.slice(0, 85) + ' ' + n;
      }
      seenTitles[title.toLowerCase()] = true;
      return [csvEsc(title),csvEsc(p.imageUrl),csvEsc(board),csvEsc(descFull),csvEsc(url)].join(',');
    });
    if (!rows.length) { showToast('Aucun pin avec image'); return; }
    downloadText('\uFEFF'+[hdr.join(',')].concat(rows).join('\n'), 'pinterest-affiliation-'+ts()+'.csv', 'text/csv;charset=utf-8');
    showToast('CSV Affiliation : '+rows.length+' pins exportes');
  }

  // ── Export JSON ───────────────────────────────────────────────────────────────
  function exportJSON() {
    var pins = getPinsToExport();
    if (!pins.length) { showToast('Aucun pin a exporter'); return; }
    var data = { exportedAt: new Date().toISOString(), total: pins.length, pins: pins.map(function(p) {
      return { id:p.id, title:p.title, description:p.description, pinUrl:p.pinUrl, imageUrl:p.imageUrl, imageUrlOrig:p.imageUrlOrig, saves:p.saves, comments:p.comments, shares:p.shares, reactions:p.reactions, viralScore:p.viralScore, isHot:p.isHot, isEarly:p.isEarly, aspectRatio:p.aspectRatio, createdAt:p.createdAt, boardName:p.boardName, boardUrl:p.boardUrl, pinner:p.pinner, pinnerUrl:p.pinnerUrl, bookmarked:p.bookmarked };
    })};
    downloadText(JSON.stringify(data, null, 2), 'pinmetrics-'+ts()+'.json', 'application/json');
    showToast(pins.length+' pins exportes en JSON');
  }

  // ── Export ZIP ────────────────────────────────────────────────────────────────
  async function exportZIP() {
    var pins = getPinsToExport().filter(function(p){return p.imageUrl;});
    if (!pins.length) { showToast('Aucune image disponible'); return; }
    var prog=document.getElementById('zipProgress'), bar=document.getElementById('zipBar'), label=document.getElementById('zipLabel');
    prog.style.display=''; bar.style.width='0%';
    var files=[], done=0, total=pins.length, errors=0;
    for (var i=0; i<pins.length; i++) {
      var pin = pins[i];
      label.textContent = (done+1)+'/'+total+' — '+((pin.title||pin.id).slice(0,40))+'...';
      try {
        var result = await chrome.runtime.sendMessage({ action:'fetchImageAsBase64', url:pin.imageUrl });
        if (result && result.success && result.base64) {
          var binary=atob(result.base64), bytes=new Uint8Array(binary.length);
          for (var j=0;j<binary.length;j++) bytes[j]=binary.charCodeAt(j);
          var safe=(pin.title||pin.id).replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,50);
          files.push({ name:pin.id+'_'+safe+'.'+(result.ext||'jpg'), data:bytes });
        } else errors++;
      } catch(e) { errors++; }
      done++;
      bar.style.width=Math.round(done/total*100)+'%';
    }
    if (!files.length) { prog.style.display='none'; showToast('Aucune image telechargeable'); return; }
    label.textContent='Creation du ZIP...';
    var zipBlob=buildZip(files), url=URL.createObjectURL(zipBlob);
    var a=document.createElement('a'); a.href=url; a.download='pinmetrics-images-'+ts()+'.zip';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function(){URL.revokeObjectURL(url);},10000);
    prog.style.display='none'; bar.style.width='0%';
    showToast('ZIP de '+files.length+' images cree'+(errors>0?' ('+errors+' erreurs)':''));
  }

  function buildZip(files) {
    var crcTable=new Uint32Array(256);
    for(var i=0;i<256;i++){var c=i;for(var j=0;j<8;j++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);crcTable[i]=c;}
    function crc32(d){var c=0xFFFFFFFF;for(var i=0;i<d.length;i++)c=crcTable[(c^d[i])&0xFF]^(c>>>8);return(c^0xFFFFFFFF)>>>0;}
    var enc=new TextEncoder();
    function w16(v){return[v&0xFF,(v>>8)&0xFF];}
    function w32(v){return[v&0xFF,(v>>8)&0xFF,(v>>16)&0xFF,(v>>24)&0xFF];}
    function concat(parts){var tot=parts.reduce(function(s,a){return s+a.length;},0),out=new Uint8Array(tot),pos=0;for(var i=0;i<parts.length;i++){out.set(parts[i],pos);pos+=parts[i].length;}return out;}
    var locals=[],cds=[],offset=0;
    for(var fi=0;fi<files.length;fi++){
      var f=files[fi],name=enc.encode(f.name),data=f.data instanceof Uint8Array?f.data:new Uint8Array(f.data),crc=crc32(data),size=data.length;
      var lh=new Uint8Array([0x50,0x4B,0x03,0x04,...w16(20),...w16(0),...w16(0),...w16(0),...w16(0),...w32(crc),...w32(size),...w32(size),...w16(name.length),...w16(0),...name]);
      var cd=new Uint8Array([0x50,0x4B,0x01,0x02,...w16(20),...w16(20),...w16(0),...w16(0),...w16(0),...w16(0),...w32(crc),...w32(size),...w32(size),...w16(name.length),...w16(0),...w16(0),...w16(0),...w16(0),...w32(0),...w32(offset),...name]);
      locals.push(lh,data);cds.push(cd);offset+=lh.length+data.length;
    }
    var cdBytes=concat(cds),count=files.length;
    var eocd=new Uint8Array([0x50,0x4B,0x05,0x06,...w16(0),...w16(0),...w16(count),...w16(count),...w32(cdBytes.length),...w32(offset),...w16(0)]);
    return new Blob([concat([...locals,cdBytes,eocd])],{type:'application/zip'});
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // ONGLET TENDANCES
  // ══════════════════════════════════════════════════════════════════════════════
  async function loadTrends() {
    trendsLoaded = true;
    showTrendsLoading();

    var country = document.getElementById('trendsCountry').value;
    var window_ = document.getElementById('trendsWindow').value;
    var today   = new Date();
    var endDate = today.toISOString().slice(0,10);

    var url = 'https://trends.pinterest.com/top_trends_filtered/' +
      '?lookbackWindow=' + window_ +
      '&endDate=' + endDate +
      '&rankingMethod=3' +
      '&country=' + country +
      '&trendsPreset=3' +
      '&numTermsToReturn=' + document.getElementById('trendsCount').value;

    try {
      var result = await chrome.runtime.sendMessage({ action: 'fetchTopTrends', url: url });
      if (!result || !result.success) throw new Error(result ? result.error : 'Erreur reseau');
      var data = result.data;
      if (!data.values || !data.values.length) throw new Error('Aucune donnee');
      allTrends = data.values.map(function(item, idx) {
        var momVal = item.mom_change ? item.mom_change.value : (item.yoy_change ? item.yoy_change.value : 0);
        var isRising = momVal > 5;
        var isHot    = item.normalizedCount >= 30;
        var isSeasonal = item.seasonality_score && item.seasonality_score > 0.5;
        return {
          rank: idx + 1,
          term: item.term || '',
          normalizedCount: item.normalizedCount || 0,
          searchCount: item.searchCount || item.normalizedCount || 0,
          momChange: momVal,
          yoyChange: item.yoy_change ? item.yoy_change.value : momVal,
          seasonalityScore: item.seasonality_score || 0,
          reverseRank: item.reverseRank || (20 - idx),
          isRising: isRising,
          isHot: isHot,
          isSeasonal: isSeasonal
        };
      });
      var maxVol = Math.max.apply(null, allTrends.map(function(t){return t.normalizedCount;}));
      allTrends.forEach(function(t){ t.maxVol = maxVol; });

      renderTrends();
      renderTrendsStats(country);
      set('trendsUpdate', 'Mis a jour le ' + new Date().toLocaleTimeString('fr-FR', {hour:'2-digit',minute:'2-digit'}));
    } catch(e) {
      showTrendsError(e.message);
    }
  }

  function renderTrends() {
    var search = (document.getElementById('trendsSearch').value||'').toLowerCase();

    filteredTrends = allTrends.filter(function(t) {
      if (search && !t.term.toLowerCase().includes(search)) return false;
      if (trendsFilter === 'rising'   && !t.isRising)   return false;
      if (trendsFilter === 'top'      && !t.isHot)      return false;
      if (trendsFilter === 'seasonal' && !t.isSeasonal) return false;
      return true;
    });

    var grid = document.getElementById('trendsGrid');
    if (!filteredTrends.length) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:#6b7280;">Aucune tendance pour ce filtre.</div>';
      grid.style.display = '';
      document.getElementById('trendsLoading').style.display  = 'none';
      document.getElementById('trendsError').style.display    = 'none';
      return;
    }

    // Couleurs par groupe
    var colors = ['#E60023','#7c3aed','#0ea5e9','#10b981','#f59e0b','#ec4899','#8b5cf6','#14b8a6','#f97316','#6366f1'];

    grid.innerHTML = filteredTrends.map(function(t, idx) {
      var color = colors[idx % colors.length];
      var momSign = t.momChange > 0 ? '+' : '';
      var momClass = t.momChange > 0 ? 'positive' : t.momChange < 0 ? 'negative' : 'neutral';
      var pct = t.maxVol > 0 ? Math.round(t.normalizedCount / t.maxVol * 100) : 0;
      var rankLabel = '#' + t.rank;
      var rankClass = t.rank <= 3 ? 'rank-top3' : '';

      var badges = '';
      if (t.isRising)   badges += '<span class="trend-badge trend-badge-rising">En hausse</span>';
      if (t.isHot)      badges += '<span class="trend-badge trend-badge-hot">Top volume</span>';
      if (t.isSeasonal) badges += '<span class="trend-badge trend-badge-seasonal">Saisonnier</span>';

      var seasonPct = t.isSeasonal ? Math.round(t.seasonalityScore * 100) + '% saisonnier' : '';

      return '<div class="trend-card" style="--trend-color:' + color + '" data-term="' + esc(t.term) + '">' +
        '<div class="trend-card-top">' +
          '<span class="trend-rank ' + rankClass + '">' + rankLabel + '</span>' +
          (badges ? '<div class="trend-badges">' + badges + '</div>' : '') +
        '</div>' +
        '<div class="trend-keyword">' + esc(t.term) + '</div>' +
        '<div class="trend-metrics">' +
          '<div class="trend-metric"><span class="trend-metric-label">Volume</span><span class="trend-metric-val neutral">' + fmt(t.normalizedCount) + '</span></div>' +
          '<div class="trend-metric"><span class="trend-metric-label">Hausse/mois</span><span class="trend-metric-val ' + momClass + '">' + momSign + t.momChange.toFixed(0) + '%</span></div>' +
          '<div class="trend-metric"><span class="trend-metric-label">Recherches</span><span class="trend-metric-val neutral">' + fmt(t.searchCount) + '</span></div>' +
        '</div>' +
        '<div class="trend-volume-bar"><div class="trend-volume-fill" style="width:' + pct + '%"></div></div>' +
        '<div class="trend-action">' +
          '<button class="trend-search-btn" data-term="' + esc(t.term) + '">🔍 Chercher sur Pinterest</button>' +
          (seasonPct ? '<span class="trend-season">' + seasonPct + '</span>' : '') +
        '</div>' +
      '</div>';
    }).join('');

    // Listeners : clic sur "Chercher sur Pinterest"
    grid.querySelectorAll('.trend-search-btn').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        var term = btn.dataset.term;
        chrome.tabs.create({ url: 'https://www.pinterest.com/search/pins/?q=' + encodeURIComponent(term) });
      });
    });

    // Clic sur la carte → ouvre le panneau détail avec graphe
    grid.querySelectorAll('.trend-card').forEach(function(card) {
      card.addEventListener('click', function(e) {
        if (e.target.closest('.trend-search-btn')) return;
        var term = card.dataset.term;
        openTrendDetail(term);
      });
    });

    document.getElementById('trendsLoading').style.display = 'none';
    document.getElementById('trendsError').style.display   = 'none';
    document.getElementById('trendsStats').style.display   = '';
    grid.style.display = '';
  }

  function renderTrendsStats(country) {
    var avg = allTrends.length ? (allTrends.reduce(function(s,t){return s+t.momChange;},0)/allTrends.length).toFixed(0) : 0;
    var maxVol = allTrends.length ? Math.max.apply(null, allTrends.map(function(t){return t.normalizedCount;})) : 0;
    set('tStatCount',   allTrends.length);
    set('tStatAvgChange', (avg>0?'+':'')+avg+'%');
    set('tStatMaxVol',  fmt(maxVol));
    set('tStatCountry', country);
  }

  function showTrendsLoading() {
    document.getElementById('trendsLoading').style.display = '';
    document.getElementById('trendsError').style.display   = 'none';
    document.getElementById('trendsGrid').style.display    = 'none';
    document.getElementById('trendsStats').style.display   = 'none';
  }

  function showTrendsError(msg) {
    document.getElementById('trendsLoading').style.display = 'none';
    document.getElementById('trendsGrid').style.display    = 'none';
    document.getElementById('trendsStats').style.display   = 'none';
    document.getElementById('trendsError').style.display   = '';
    set('trendsErrorMsg', msg || "Assure-toi d'etre connecte a trends.pinterest.com dans Opera.");
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // EVENTS
  // ══════════════════════════════════════════════════════════════════════════════
  document.getElementById('refreshBtn').addEventListener('click', loadPins);

  document.getElementById('debugBtn').addEventListener('click', function() {
    chrome.storage.local.get(null, function(items) {
      var keys = Object.keys(items);
      var pinKeys = keys.filter(function(k){return k.startsWith('pin_');});
      alert('Storage total : '+keys.length+' cles\nFormat pin_XXX : '+pinKeys.length+' pins\nDashboard affiche : '+allPins.length+' pins');
    });
  });

  // Filtres pins
  ['searchInput','periodFilter','ratioFilter','minSaves','minViral','textFilter'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) { el.addEventListener('input', apply); el.addEventListener('change', apply); }
  });
  ['hotOnly','earlyOnly','bookmarkedOnly'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('change', apply);
  });
  document.getElementById('clearFilters').addEventListener('click', function() {
    document.getElementById('searchInput').value='';
    document.getElementById('periodFilter').value='all';
    document.getElementById('ratioFilter').value='all';
    document.getElementById('minSaves').value='';
    document.getElementById('minViral').value='';
    document.getElementById('hotOnly').checked=false;
    document.getElementById('earlyOnly').checked=false;
    document.getElementById('bookmarkedOnly').checked=false;
    var tf = document.getElementById('textFilter'); if (tf) tf.value='all';
    apply();
  });

  // Sort
  document.querySelectorAll('th.sortable').forEach(function(th) {
    th.addEventListener('click', function() {
      if (sortCol===th.dataset.col) sortDir=sortDir==='desc'?'asc':'desc';
      else {sortCol=th.dataset.col;sortDir='desc';}
      apply();
    });
  });

  // Sélection
  document.getElementById('selectAll').addEventListener('change', function(e) {
    if (e.target.checked) filtered.forEach(function(p){selected.add(p.id);});
    else filtered.forEach(function(p){selected.delete(p.id);});
    render(); updateSelCount();
  });
  document.getElementById('headerCheck').addEventListener('change', function(e) {
    getCurrentPageIds().forEach(function(id){if(e.target.checked)selected.add(id);else selected.delete(id);});
    render(); updateSelCount();
  });

  // Vue
  document.getElementById('viewTable').addEventListener('click', function() {
    viewMode='table';
    document.getElementById('viewTable').classList.add('active');
    document.getElementById('viewGrid').classList.remove('active');
    document.getElementById('tableView').style.display='';
    document.getElementById('gridView').style.display='none';
    render();
  });
  document.getElementById('viewGrid').addEventListener('click', function() {
    viewMode='grid';
    document.getElementById('viewGrid').classList.add('active');
    document.getElementById('viewTable').classList.remove('active');
    document.getElementById('tableView').style.display='none';
    document.getElementById('gridView').style.display='';
    render();
  });

  // Export
  document.getElementById('exportCsvBtn').addEventListener('click', function() {
    var panel=document.getElementById('csvParams');
    if (panel.style.display==='none') { panel.style.display=''; panel.scrollIntoView({behavior:'smooth',block:'nearest'}); document.getElementById('csvBoard').focus(); }
    else exportCSV();
  });
  document.getElementById('exportJsonBtn').addEventListener('click', exportJSON);
  document.getElementById('exportZipBtn').addEventListener('click', exportZIP);
  document.getElementById('csvExportNow').addEventListener('click', exportCSV);
  document.getElementById('csvParamsClose').addEventListener('click', function() { document.getElementById('csvParams').style.display='none'; });

  // Envoyer la sélection vers Pin Maker
  document.getElementById('sendToPinMakerBtn').addEventListener('click', function() {
    var pinsToSend = allPins.filter(function(p) { return selected.has(p.id) && p.imageUrl; });
    if (!pinsToSend.length) { showToast('Sélectionne au moins un pin d\'abord'); return; }

    // Basculer sur l'onglet Pin Maker
    document.querySelectorAll('.nav-btn').forEach(function(b) { b.classList.remove('active'); });
    var pmBtn = document.querySelector('.nav-btn[data-tab="pinmaker"]');
    if (pmBtn) pmBtn.classList.add('active');
    document.getElementById('tabPins').style.display     = 'none';
    document.getElementById('tabTrends').style.display   = 'none';
    document.getElementById('tabPinmaker').style.display = '';

    // Initialiser Pin Maker si pas encore fait
    if (!window._pmInited) { window._pmInited = true; initPinMaker(); }

    // Injecter la sélection dans pmAllImages et pré-sélectionner tout
    // On passe par un événement custom pour traverser la closure de initPinMaker
    window._pmInjectSelection = pinsToSend.map(function(p) {
      return { id: p.id, imageUrl: p.imageUrl, title: p.title || '' };
    });
    // Délai court pour laisser initPinMaker s'enregistrer si premier appel
    setTimeout(function() {
      document.dispatchEvent(new CustomEvent('pm:injectSelection'));
    }, 50);
    showToast(pinsToSend.length + ' pins envoyés vers Pin Maker ✓');
  });

  // Mode CSV
  document.getElementById('modeBlogBtn').addEventListener('click', function() {
    csvMode='blog';
    document.getElementById('modeBlogBtn').classList.add('active');
    document.getElementById('modeAffBtn').classList.remove('active');
    document.getElementById('modeBlog').style.display='';
    document.getElementById('modeAff').style.display='none';
  });
  document.getElementById('modeAffBtn').addEventListener('click', function() {
    csvMode='aff';
    document.getElementById('modeAffBtn').classList.add('active');
    document.getElementById('modeBlogBtn').classList.remove('active');
    document.getElementById('modeAff').style.display='';
    document.getElementById('modeBlog').style.display='none';
  });
  document.getElementById('affDesc').addEventListener('input', function(e) {
    var w=document.getElementById('adWarn');
    if (w) w.style.display=e.target.value&&!e.target.value.includes('#ad')?'':'none';
  });

  // Tendances

  // ── Détail d'une tendance au clic (données déjà en mémoire) ───────────────
  function openTrendDetail(term) {
    var panel  = document.getElementById('trendDetail');
    var termEl = document.getElementById('trendDetailTerm');
    var loading= document.getElementById('trendDetailLoading');
    var contentEl = document.getElementById('trendDetailContent');

    // Trouver le trend dans allTrends
    var t = allTrends.find(function(x){ return x.term === term; });
    if (!t) return;

    termEl.textContent = t.term;
    panel.style.display = '';
    loading.style.display = 'none';
    contentEl.style.display = '';
    panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    document.getElementById('trendDetailSearch').dataset.term = t.term;

    function fmtRate(v) {
      if (v == null || v === 0) return '—';
      return (v > 0 ? '+' : '') + (v * 100).toFixed(0) + '%';
    }
    function rateClass(v) { return !v ? '' : v > 0 ? 'positive' : 'negative'; }

    // Badges
    var badges = '';
    if (t.isRising)   badges += '<span class="trend-badge trend-badge-rising">En hausse</span> ';
    if (t.isHot)      badges += '<span class="trend-badge trend-badge-hot">Top volume</span> ';
    if (t.isSeasonal) badges += '<span class="trend-badge trend-badge-seasonal">Saisonnier</span>';

    document.getElementById('trendDetailMetrics').innerHTML =
      (badges ? '<div style="margin-bottom:10px;">' + badges + '</div>' : '') +
      '<div class="kw-result-metrics">' +
        '<div class="kw-metric"><div class="kw-metric-label">Rang</div><div class="kw-metric-val neutral">#' + t.rank + '</div></div>' +
        '<div class="kw-metric"><div class="kw-metric-label">Volume</div><div class="kw-metric-val neutral">' + fmt(t.normalizedCount) + '</div></div>' +
        '<div class="kw-metric"><div class="kw-metric-label">Hausse / mois</div><div class="kw-metric-val ' + rateClass(t.momChange) + '">' + fmtRate(t.momChange) + '</div></div>' +
        '<div class="kw-metric"><div class="kw-metric-label">Saisonnalite</div><div class="kw-metric-val neutral">' + (t.isSeasonal ? Math.round(t.seasonalityScore * 100) + '%' : '—') + '</div></div>' +
      '</div>' +
      '<div style="margin-top:12px;padding:12px;background:#f9fafb;border-radius:8px;">' +
        '<div style="font-size:11px;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px;">Actions</div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
          '<button class="trend-search-btn detail-action" data-action="pinterest" data-term="' + esc(t.term) + '">🔍 Voir les pins Pinterest</button>' +
          '<button class="trend-search-btn detail-action" data-action="trends" data-term="' + esc(t.term) + '">📈 Ouvrir dans Pinterest Trends</button>' +
        '</div>' +
      '</div>';

    // Listeners actions
    contentEl.querySelectorAll('.detail-action').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var action = btn.dataset.action;
        var term2  = btn.dataset.term;
        if (action === 'pinterest') {
          chrome.tabs.create({ url: 'https://www.pinterest.com/search/pins/?q=' + encodeURIComponent(term2) });
        } else {
          chrome.tabs.create({ url: 'https://trends.pinterest.com/?term=' + encodeURIComponent(term2) });
        }
      });
    });

    contentEl.style.display = '';
  }

  // Fermer le panneau détail
  document.getElementById('trendDetailClose').addEventListener('click', function() {
    document.getElementById('trendDetail').style.display = 'none';
  });
  document.getElementById('trendDetailSearch').addEventListener('click', function() {
    var term = document.getElementById('trendDetailSearch').dataset.term;
    if (term) chrome.tabs.create({ url: 'https://www.pinterest.com/search/pins/?q=' + encodeURIComponent(term) });
  });

  document.getElementById('trendsRefreshBtn').addEventListener('click', function() {
    trendsLoaded=false; loadTrends();
  });
  document.getElementById('trendsCountry').addEventListener('change', function() { trendsLoaded=false; loadTrends(); });
  document.getElementById('trendsWindow').addEventListener('change', function() { trendsLoaded=false; loadTrends(); });
  document.getElementById('trendsRetryBtn').addEventListener('click', function() { trendsLoaded=false; loadTrends(); });
  document.getElementById('trendsSearch').addEventListener('input', renderTrends);

  // ── Export Briefing Claude ────────────────────────────────────────────────────
  var CPC_NICHES = [
    { niche: 'coiffure',      keywords: ['coiffure','coupe','cheveux','bixie','bob','frange','coloration','gris','balayage','brushing','chignon','tresse'] },
    { niche: 'mode',          keywords: ['mode','tenue','outfit','look','robe','jean','blazer','manteau','veste','chemise','pantalon','jupe','style','fashion','chic'] },
    { niche: 'grande taille', keywords: ['grande taille','curvy','plus size','oversize'] },
    { niche: 'beaute',        keywords: ['beauté','soin','anti-age','sérum','crème','maquillage','fond de teint','rouge','mascara','sourcils','ongles','nail','vernis','routine'] },
    { niche: 'deco',          keywords: ['déco','décoration','intérieur','salon','chambre','cuisine','salle de bain','canapé','table','luminaire','plante','rangement','maison','home'] },
    { niche: 'accessoires',   keywords: ['sac','chaussures','bijoux','collier','bracelet','bague','montre','lunettes','ceinture','écharpe','chapeau','accessoires'] },
    { niche: 'faible_cpc',    keywords: ['recette','cuisine','ménage','nettoyage','diy','remède','bricolage','astuce maison'] }
  ];

  function detectCpcNiche(term) {
    var t = term.toLowerCase();
    for (var i = 0; i < CPC_NICHES.length; i++) {
      var n = CPC_NICHES[i];
      for (var j = 0; j < n.keywords.length; j++) {
        if (t.indexOf(n.keywords[j]) !== -1) return n.niche;
      }
    }
    return 'autre';
  }

  function exportClaudeBriefing() {
    if (!filteredTrends.length) {
      showToast('Aucune tendance — charge les trends d\'abord');
      return;
    }
    var country = document.getElementById('trendsCountry').value;
    var winEl   = document.getElementById('trendsWindow');
    var window_ = winEl.options[winEl.selectedIndex].text;

    var trendsOut = filteredTrends.map(function(t) {
      return {
        term:             t.term,
        normalizedCount:  t.normalizedCount,
        momChange:        t.momChange,
        searchCount:      t.searchCount,
        isRising:         t.isRising,
        isHot:            t.isHot,
        isSeasonal:       t.isSeasonal,
        seasonalityScore: t.isSeasonal ? Math.round(t.seasonalityScore * 100) : 0,
        cpcNiche:         detectCpcNiche(t.term)
      };
    });

    trendsOut.sort(function(a, b) {
      var scoreA = (a.isRising ? 2 : 0) + (a.isHot ? 1 : 0);
      var scoreB = (b.isRising ? 2 : 0) + (b.isHot ? 1 : 0);
      if (scoreB !== scoreA) return scoreB - scoreA;
      return b.normalizedCount - a.normalizedCount;
    });

    var payload = {
      type:         'PinMetrics_Trends_Briefing',
      exportedAt:   new Date().toISOString(),
      country:      country,
      window:       window_,
      activeFilter: trendsFilter,
      totalTrends:  trendsOut.length,
      trends:       trendsOut
    };

    var ts       = new Date().toISOString().slice(0,10);
    var filename = 'pinmetrics-trends-briefing-' + country + '-' + ts + '.json';
    var blob     = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    var url      = URL.createObjectURL(blob);
    var a        = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    setTimeout(function(){ URL.revokeObjectURL(url); }, 1000);
    showToast('\u2705 Briefing Claude export\u00e9 \u2014 ' + trendsOut.length + ' tendances');
  }

  document.getElementById('trendsExportClaudeBtn').addEventListener('click', exportClaudeBriefing);
  // ── Fin Export Briefing Claude ────────────────────────────────────────────────

  document.querySelectorAll('.trend-filter-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.trend-filter-btn').forEach(function(b){b.classList.remove('active');});
      btn.classList.add('active');
      trendsFilter=btn.dataset.filter;
      renderTrends();
    });
  });

  // ── Helpers ──────────────────────────────────────────────────────────────────
  function fmt(n) { if(!n&&n!==0)return'0'; n=Math.round(n); return n>=1e6?(n/1e6).toFixed(1)+'M':n>=1e3?(n/1e3).toFixed(1)+'K':String(n); }
  function fmtDate(s) { if(!s)return'—'; try{return new Date(s).toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'2-digit'});}catch{return'—';} }
  function esc(s) { return(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function ts() { return new Date().toISOString().slice(0,10); }
  function set(id,v) { var el=document.getElementById(id); if(el)el.textContent=v; }
  function showToast(msg) { var t=document.getElementById('toast'); t.textContent=msg; t.style.display=''; clearTimeout(t._t); t._t=setTimeout(function(){t.style.display='none';},3500); }
  function downloadText(content,filename,mime) {
    var a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([content],{type:mime}));
    a.download=filename; document.body.appendChild(a); a.click(); document.body.removeChild(a);
  }

  // Écoute updates content script
  chrome.runtime.onMessage.addListener(function(msg) {
    if (msg.action==='statsUpdate') loadPins();
  });

  // Ajouter trends.pinterest.com aux host_permissions via service worker
  // (déjà géré côté manifest)

  // ══════════════════════════════════════════════════════════════════════════════
  // PIN MAKER — initialisé en différé pour ne pas bloquer loadPins()
  // ══════════════════════════════════════════════════════════════════════════════
  function initPinMaker() {

    // ── State ────────────────────────────────────────────────────────────────────
    var pmAllImages = [];
    var pmSelected  = new Set();
    var pmPosition  = 'bottom';
    var pmOverlay   = 'dark';
    var pmEffect    = 'stroke';
    var pmLayout    = 'overlay';  // overlay | sticker | comic | bloc | shadow
    var pmOverlayStyle = 'gradient';
    var pmExportMode   = 'blog';
    var PM_W = 736, PM_H = 1308;

    // ── Persist GitHub settings (avec null-check) ────────────────────────────────
    var ghTokenEl = document.getElementById('pmGhToken');
    var ghUserEl  = document.getElementById('pmGhUser');
    var ghRepoEl  = document.getElementById('pmGhRepo');
    if (ghTokenEl) { ghTokenEl.value = localStorage.getItem('pm_gh_token') || ''; ghTokenEl.addEventListener('change', function(){ localStorage.setItem('pm_gh_token', this.value); }); }
    if (ghUserEl)  { ghUserEl.value  = localStorage.getItem('pm_gh_user')  || 'achinej-sketch'; ghUserEl.addEventListener('change', function(){ localStorage.setItem('pm_gh_user', this.value); }); }
    if (ghRepoEl)  { ghRepoEl.value  = localStorage.getItem('pm_gh_repo')  || 'pinterest-temp'; ghRepoEl.addEventListener('change', function(){ localStorage.setItem('pm_gh_repo', this.value); }); }

    // ── Position buttons ─────────────────────────────────────────────────────────
    document.querySelectorAll('.pm-pos-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.pm-pos-btn').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        pmPosition = this.dataset.pos;
        pmRenderSelected();
      });
    });

    // ── Overlay buttons ───────────────────────────────────────────────────────────
    document.querySelectorAll('.pm-overlay-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.pm-overlay-btn').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        pmOverlay = this.dataset.overlay;
        pmRenderSelected();
      });
    });

    // ── Effect buttons ────────────────────────────────────────────────────────────
    document.querySelectorAll('.pm-effect-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.pm-effect-btn').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        pmEffect = this.dataset.effect;
        pmRenderSelected();
      });
    });

    // ── Layout buttons ───────────────────────────────────────────────────────────
    document.querySelectorAll('.pm-layout-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.pm-layout-btn').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        pmLayout = this.dataset.layout;
        pmRenderSelected();
      });
    });

    // ── Overlay style buttons ────────────────────────────────────────────────────
    document.querySelectorAll('.pm-ovstyle-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.pm-ovstyle-btn').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        pmOverlayStyle = this.dataset.ovstyle;
        pmRenderSelected();
      });
    });

    // ── Mode blog / amazon ───────────────────────────────────────────────────────
    document.querySelectorAll('.pm-mode-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.pm-mode-btn').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        pmExportMode = this.dataset.mode;
        document.getElementById('pmModeBlog').style.display    = pmExportMode === 'blog'   ? '' : 'none';
        document.getElementById('pmModeAmazon').style.display  = pmExportMode === 'amazon' ? '' : 'none';
        var adWarn = document.getElementById('pmAdWarnLabel');
        if (adWarn) adWarn.style.display = pmExportMode === 'amazon' ? '' : 'none';
        localStorage.setItem('pm_export_mode', pmExportMode);
      });
    });

    // ── Tag affilié buttons (Pin Maker) ──────────────────────────────────────
    var pmTagBtns = document.getElementById('pmTagBtns');
    if (pmTagBtns) {
      pmTagBtns.querySelectorAll('.pm-tag-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
          pmTagBtns.querySelectorAll('.pm-tag-btn').forEach(function(b){ b.classList.remove('active'); });
          this.classList.add('active');
          document.getElementById('pmAffTag').value = this.dataset.tag;
          localStorage.setItem('pm_aff_tag', this.dataset.tag);
        });
      });
    }

    // ── Tag affilié buttons (onglet Mes Pins — CSV params) ───────────────────
    var affTagBtns = document.getElementById('affTagBtns');
    if (affTagBtns) {
      affTagBtns.querySelectorAll('.pm-tag-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
          affTagBtns.querySelectorAll('.pm-tag-btn').forEach(function(b){ b.classList.remove('active'); });
          this.classList.add('active');
          document.getElementById('affTag').value = this.dataset.tag;
          localStorage.setItem('aff_tag', this.dataset.tag);
        });
      });
    }

    // ── Persistence champs Export ─────────────────────────────────────────────
    var pmPersistFields = [
      'pmBoard', 'pmDescription', 'pmHashtags', 'pmPublishDate',
      'pmDestUrl', 'pmAffLien'
    ];
    pmPersistFields.forEach(function(id) {
      var el = document.getElementById(id);
      if (!el) return;
      var saved = localStorage.getItem('pm_field_' + id);
      if (saved) el.value = saved;
      el.addEventListener('input', function(){ localStorage.setItem('pm_field_' + id, this.value); });
    });

    // Restaurer le mode export
    var savedMode = localStorage.getItem('pm_export_mode') || 'blog';
    pmExportMode = savedMode;
    var savedModeBtn = document.querySelector('.pm-mode-btn[data-mode="' + savedMode + '"]');
    if (savedModeBtn) {
      document.querySelectorAll('.pm-mode-btn').forEach(function(b){ b.classList.remove('active'); });
      savedModeBtn.classList.add('active');
      var blogEl   = document.getElementById('pmModeBlog');
      var amazonEl = document.getElementById('pmModeAmazon');
      var adWarnEl = document.getElementById('pmAdWarnLabel');
      if (blogEl)   blogEl.style.display   = savedMode === 'blog'   ? '' : 'none';
      if (amazonEl) amazonEl.style.display = savedMode === 'amazon' ? '' : 'none';
      if (adWarnEl) adWarnEl.style.display = savedMode === 'amazon' ? '' : 'none';
    }

    // Restaurer le tag affilié PM
    var savedTag = localStorage.getItem('pm_aff_tag') || 'astucieusement-21';
    document.getElementById('pmAffTag').value = savedTag;
    if (pmTagBtns) {
      pmTagBtns.querySelectorAll('.pm-tag-btn').forEach(function(b){
        b.classList.toggle('active', b.dataset.tag === savedTag);
      });
    }

    // Restaurer le tag affilié onglet Pins
    var savedAffTag = localStorage.getItem('aff_tag') || 'astucieusement-21';
    var affTagEl = document.getElementById('affTag');
    if (affTagEl) affTagEl.value = savedAffTag;
    if (affTagBtns) {
      affTagBtns.querySelectorAll('.pm-tag-btn').forEach(function(b){
        b.classList.toggle('active', b.dataset.tag === savedAffTag);
      });
    }

    // ── Live re-render ────────────────────────────────────────────────────────────
    ['pmTitle','pmFont','pmFontSize','pmAccentSize','pmLineHeight','pmPadding','pmColorMain','pmColorAccent','pmOverlayOpacity'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('input', pmRenderSelected);
    });

    // Mise à jour des labels des sliders (remplace les oninput inline bloqués par CSP)
    function pmBindSliderLabel(sliderId, labelId, fmt) {
      var sl = document.getElementById(sliderId);
      var lb = document.getElementById(labelId);
      if (!sl || !lb) return;
      lb.textContent = fmt(sl.value);
      sl.addEventListener('input', function() { lb.textContent = fmt(this.value); });
    }
    pmBindSliderLabel('pmFontSize',       'pmFontSizeVal',  function(v){ return v + 'px'; });
    pmBindSliderLabel('pmAccentSize',     'pmAccentSizeVal',function(v){ return v + 'px'; });
    pmBindSliderLabel('pmOverlayOpacity', 'pmOpacityVal',   function(v){ return Math.round(v*100) + '%'; });
    pmBindSliderLabel('pmLineHeight',     'pmLineHeightVal', function(v){ return parseFloat(v).toFixed(2); });
    pmBindSliderLabel('pmPadding',        'pmPaddingVal',   function(v){ return v + 'px'; });

    // ══════════════════════════════════════════════════════════════════════════════
    // SOURCE
    // ══════════════════════════════════════════════════════════════════════════════

    // Pins collectés → galerie de sélection
    var _el_pmUseCached = document.getElementById('pmUseCached'); if (_el_pmUseCached) _el_pmUseCached.addEventListener('click', function() {
      chrome.storage.local.get(null, function(items) {
        var pins = [];
        for (var k in items) {
          if (k.startsWith('pin_') && items[k] && items[k].imageUrl) pins.push(items[k]);
        }
        if (!pins.length) { showToast('Aucun pin collecté — navigue sur Pinterest d\'abord'); return; }
        pmAllImages = pins.map(function(p){ return { id: p.id, imageUrl: p.imageUrl, title: p.title||'' }; });
        pmSelected.clear();
        pmShowSource(pmAllImages.length + ' pins disponibles — clique pour sélectionner');
        document.getElementById('pmSelBtns').style.display = '';
        pmBuildSelectionGallery();
      });
    });

    // ZIP
    var _el_pmZipInput = document.getElementById('pmZipInput'); if (_el_pmZipInput) _el_pmZipInput.addEventListener('change', function(e) {
      var file = e.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function(ev) {
        var bytes = new Uint8Array(ev.target.result);
        var imgs  = pmParseZip(bytes);
        if (!imgs.length) { showToast('Aucune image trouvée dans le ZIP'); return; }
        pmAllImages = imgs.map(function(img, i){ return { id: 'zip_'+i, imageUrl: img.dataUrl, title: img.name }; });
        pmSelected.clear();
        pmShowSource(pmAllImages.length + ' images disponibles — clique pour sélectionner');
        document.getElementById('pmSelBtns').style.display = '';
        pmBuildSelectionGallery();
      };
      reader.readAsArrayBuffer(file);
    });

    // Réception de la sélection depuis "Mes Pins"
    document.addEventListener('pm:injectSelection', function() {
      if (!window._pmInjectSelection || !window._pmInjectSelection.length) return;
      pmAllImages = window._pmInjectSelection;
      window._pmInjectSelection = null;
      pmSelected.clear();
      pmAllImages.forEach(function(_, i) { pmSelected.add(i); });
      pmShowSource(pmAllImages.length + ' pins reçus depuis Mes Pins — tous pré-sélectionnés');
      document.getElementById('pmSelBtns').style.display = '';
      pmBuildSelectionGallery();
    });

    function pmShowSource(msg) {
      var el = document.getElementById('pmSourceInfo');
      el.textContent = '✅ ' + msg;
      el.style.display = '';
    }

    // Select All / None
    var _el_pmSelectAll = document.getElementById('pmSelectAll'); if (_el_pmSelectAll) _el_pmSelectAll.addEventListener('click', function() {
      pmAllImages.forEach(function(_, i){ pmSelected.add(i); });
      document.querySelectorAll('.pm-thumb').forEach(function(t){ t.classList.add('selected'); });
      pmUpdateSelCount();
    });
    var _el_pmSelectNone = document.getElementById('pmSelectNone'); if (_el_pmSelectNone) _el_pmSelectNone.addEventListener('click', function() {
      pmSelected.clear();
      document.querySelectorAll('.pm-thumb').forEach(function(t){ t.classList.remove('selected'); });
      pmUpdateSelCount();
    });

    function pmUpdateSelCount() {
      var el = document.getElementById('pmSelCount');
      if (el) el.textContent = pmSelected.size + ' sélectionné(s)';
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // GALERIE DE SÉLECTION (thumbnails cliquables)
    // ══════════════════════════════════════════════════════════════════════════════
    function pmBuildSelectionGallery() {
      var container = document.getElementById('pmPreviews');
      document.getElementById('pmEmpty').style.display = 'none';
      Array.from(container.children).forEach(function(c){ if (c.id !== 'pmEmpty') c.remove(); });

      // Barre de contrôle
      var hdr = document.createElement('div');
      hdr.id = 'pmSelHeader';
      hdr.className = 'pm-sel-header';
      hdr.innerHTML =
        '<span id="pmSelCount">0 sélectionné(s)</span>' +
        '<button id="pmConfirmSel" class="btn btn-export">✅ Valider la sélection</button>';
      container.appendChild(hdr);

      // Galerie
      var gallery = document.createElement('div');
      gallery.className = 'pm-thumb-gallery';
      gallery.id = 'pmThumbGallery';
      container.appendChild(gallery);

      pmAllImages.forEach(function(pin, idx) {
        var wrap = document.createElement('div');
        wrap.className = 'pm-thumb' + (pmSelected.has(idx) ? ' selected' : '');
        wrap.dataset.idx = idx;

        var img = document.createElement('img');
        img.src = pin.imageUrl;
        img.loading = 'lazy';
        img.crossOrigin = 'anonymous';

        var check = document.createElement('div');
        check.className = 'pm-thumb-check';
        check.innerHTML = '✓';

        wrap.appendChild(img);
        wrap.appendChild(check);
        gallery.appendChild(wrap);

        wrap.addEventListener('click', function() {
          if (pmSelected.has(idx)) {
            pmSelected.delete(idx);
            wrap.classList.remove('selected');
          } else {
            pmSelected.add(idx);
            wrap.classList.add('selected');
          }
          pmUpdateSelCount();
        });
      });

      // Init count
      pmUpdateSelCount();

      // Valider
      document.getElementById('pmConfirmSel').addEventListener('click', function() {
        if (!pmSelected.size) { showToast('Sélectionne au moins un pin'); return; }
        var indices = Array.from(pmSelected).sort(function(a,b){ return a-b; });
        pmBuildPreviewGrid(indices);
      });
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // GRILLE DE PREVIEW (canvases avec texte)
    // ══════════════════════════════════════════════════════════════════════════════
    function pmBuildPreviewGrid(indices) {
      var container = document.getElementById('pmPreviews');
      Array.from(container.children).forEach(function(c){ if (c.id !== 'pmEmpty') c.remove(); });
      document.getElementById('pmEmpty').style.display = 'none';

      // Barre retour
      var backBar = document.createElement('div');
      backBar.className = 'pm-back-bar';
      backBar.innerHTML =
        '<button id="pmBackToSel" class="btn btn-ghost btn-sm">← Modifier la sélection</button>' +
        '<span class="pm-sel-info">' + indices.length + ' pin(s) sélectionné(s)</span>';
      container.appendChild(backBar);
      document.getElementById('pmBackToSel').addEventListener('click', pmBuildSelectionGallery);

      // Grille
      var grid = document.createElement('div');
      grid.className = 'pm-grid';
      grid.id = 'pmGrid';
      container.appendChild(grid);

      indices.forEach(function(origIdx, i) {
        var pin  = pmAllImages[origIdx];
        var item = document.createElement('div');
        item.className = 'pm-item';

        var canvas = document.createElement('canvas');
        canvas.id             = 'pmCanvas_' + i;
        canvas.dataset.origIdx = origIdx;
        canvas.width  = PM_W;
        canvas.height = PM_H;

        var label = document.createElement('div');
        label.className = 'pm-item-label';
        label.textContent = pin.title || ('Pin ' + (i+1));

        item.appendChild(canvas);
        item.appendChild(label);
        grid.appendChild(item);
      });

      pmRenderSelected();
    }

    function pmRenderSelected() {
      var grid = document.getElementById('pmGrid');
      if (!grid) return;
      grid.querySelectorAll('canvas').forEach(function(canvas, i) {
        var origIdx = parseInt(canvas.dataset.origIdx);
        pmRenderOne(canvas, pmAllImages[origIdx], i);
      });
    }
    var _el_pmRenderAll = document.getElementById('pmRenderAll'); if (_el_pmRenderAll) _el_pmRenderAll.addEventListener('click', pmRenderSelected);

    // ══════════════════════════════════════════════════════════════════════════════
    // RENDU CANVAS
    // ══════════════════════════════════════════════════════════════════════════════
    function pmRenderOne(canvas, pin, displayIdx) {
      if (!canvas || !pin) return;
      var ctx      = canvas.getContext('2d');
      var titleRaw   = document.getElementById('pmTitle').value.trim() || ('Pin ' + (displayIdx+1));
      var font       = document.getElementById('pmFont').value;
      var fontSize   = parseInt(document.getElementById('pmFontSize').value) || 68;
      var accentSize = parseInt(document.getElementById('pmAccentSize').value) || 96;
      var lineHMult  = parseFloat(document.getElementById('pmLineHeight').value) || 1.2;
      var padV       = parseInt(document.getElementById('pmPadding').value) || 20;
      var colorMain  = document.getElementById('pmColorMain').value;
      var colorAcc   = document.getElementById('pmColorAccent').value;
      var opacity    = parseFloat(document.getElementById('pmOverlayOpacity').value);

      var imgEl = new Image();
      imgEl.crossOrigin = 'anonymous';
      imgEl.onload = function() {
        ctx.clearRect(0, 0, PM_W, PM_H);
        // Cover
        var scale = Math.max(PM_W / imgEl.width, PM_H / imgEl.height);
        var sw = imgEl.width * scale, sh = imgEl.height * scale;
        ctx.drawImage(imgEl, (PM_W-sw)/2, (PM_H-sh)/2, sw, sh);

        var segments = pmParseTitle(titleRaw);
        var maxW     = PM_W - 80;
        ctx.font     = '900 ' + fontSize + 'px ' + font;
        var lines    = pmWrapSegments(ctx, segments, maxW, fontSize, accentSize, font);

        // lineH basé sur la taille max réellement utilisée + multiplicateur
        var hasBig = segments.some(function(s){ return s.big; });
        var lineH  = (hasBig ? Math.max(fontSize, accentSize) : fontSize) * lineHMult;
        var textH    = lines.length * lineH;
        // padV lu depuis slider
        var overlayH = textH + padV * 2;
        var overlayY;
        if      (pmPosition === 'top')    overlayY = 0;
        else if (pmPosition === 'center') overlayY = (PM_H - overlayH) / 2;
        else                              overlayY = PM_H - overlayH;

        // ── Dispatch selon layout ─────────────────────────────────────────────
        if (pmLayout === 'overlay') {
          pmLayoutOverlay(ctx, lines, overlayY, overlayH, padV, fontSize, accentSize, lineH, font,
            colorMain, colorAcc, opacity, pmOverlay, pmOverlayStyle, pmEffect);
        } else if (pmLayout === 'sticker') {
          pmLayoutSticker(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, pmEffect);
        } else if (pmLayout === 'comic') {
          pmLayoutComic(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, pmEffect);
        } else if (pmLayout === 'bloc') {
          pmLayoutBloc(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, pmEffect, opacity);
        } else if (pmLayout === 'shadow') {
          pmLayoutShadow(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, pmEffect);
        }
      };
      imgEl.onerror = function() {
        ctx.fillStyle = '#1a1a2e'; ctx.fillRect(0,0,PM_W,PM_H);
        ctx.fillStyle = '#fff'; ctx.font = '26px sans-serif'; ctx.textAlign='center';
        ctx.fillText('Image non disponible', PM_W/2, PM_H/2); ctx.textAlign='left';
      };
      imgEl.src = pin.imageUrl;
    }


    // ══════════════════════════════════════════════════════════════════════════════
    // LAYOUTS
    // ══════════════════════════════════════════════════════════════════════════════

    // Helper : mesure largeur totale d'une ligne
    function pmLineWidth(ctx, segs, fontSize, accentSize, font) {
      return segs.reduce(function(acc, s) {
        ctx.font = '900 ' + (s.big ? accentSize : fontSize) + 'px ' + font;
        return acc + ctx.measureText(s.t).width;
      }, 0);
    }

    // Helper : dessine une ligne centrée
    function pmDrawLine(ctx, segs, y, fontSize, accentSize, font, colorMain, colorAcc, effect, PM_W) {
      ctx.font = '900 ' + fontSize + 'px ' + font;
      var totalW = pmLineWidth(ctx, segs, fontSize, accentSize, font);
      var x = (PM_W - totalW) / 2;
      segs.forEach(function(s) {
        var sz = s.big ? accentSize : fontSize;
        ctx.font = '900 ' + sz + 'px ' + font;
        pmDrawEffect(ctx, s.t, x, y, sz, s.accent ? colorAcc : colorMain, colorAcc, effect);
        x += ctx.measureText(s.t).width;
      });
    }

    // ── Layout OVERLAY (défaut) ───────────────────────────────────────────────────
    function pmLayoutOverlay(ctx, lines, overlayY, overlayH, padV, fontSize, accentSize, lineH, font,
        colorMain, colorAcc, opacity, pmOverlay, pmOverlayStyle, effect) {
      if (pmOverlay !== 'none') {
        ctx.save();
        var col = pmOverlay === 'dark' ? '0,0,0' : '255,255,255';
        if (pmOverlayStyle === 'gradient') {
          var grd = ctx.createLinearGradient(0, overlayY, 0, overlayY + overlayH);
          grd.addColorStop(0,    'rgba(' + col + ',0)');
          grd.addColorStop(0.18, 'rgba(' + col + ',' + opacity + ')');
          grd.addColorStop(0.82, 'rgba(' + col + ',' + opacity + ')');
          grd.addColorStop(1,    'rgba(' + col + ',0)');
          ctx.fillStyle = grd;
        } else {
          ctx.fillStyle = 'rgba(' + col + ',' + opacity + ')';
        }
        ctx.fillRect(0, overlayY, PM_W, overlayH);
        ctx.restore();
      }
      var startY = overlayY + padV + fontSize;
      lines.forEach(function(segs, li) {
        pmDrawLine(ctx, segs, startY + li * lineH, fontSize, accentSize, font, colorMain, colorAcc, effect, PM_W);
      });
    }

    // ── Layout STICKER : texte flottant sans fond, outline blanc épais ────────────
    function pmLayoutSticker(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, effect) {
      var totalH  = lines.length * lineH;
      var startY  = (PM_H - totalH) / 2 + fontSize;
      lines.forEach(function(segs, li) {
        var y  = startY + li * lineH;
        var sz = segs.some(function(s){ return s.big; }) ? accentSize : fontSize;
        ctx.font = '900 ' + sz + 'px ' + font;
        var totalW = pmLineWidth(ctx, segs, fontSize, accentSize, font);
        var x = (PM_W - totalW) / 2;
        segs.forEach(function(s) {
          var fsz = s.big ? accentSize : fontSize;
          ctx.font = '900 ' + fsz + 'px ' + font;
          // Outline blanc très épais = effet sticker
          ctx.lineWidth   = Math.max(12, fsz * 0.22);
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = '#ffffff';
          ctx.strokeText(s.t, x, y);
          // Outline noir fin par dessus
          ctx.lineWidth   = Math.max(3, fsz * 0.04);
          ctx.strokeStyle = 'rgba(0,0,0,0.15)';
          ctx.strokeText(s.t, x, y);
          // Fill couleur
          ctx.fillStyle = s.accent ? colorAcc : colorMain;
          ctx.fillText(s.t, x, y);
          x += ctx.measureText(s.t).width;
        });
      });
    }

    // ── Layout COMIC : fond noir arrondi par ligne, style BD ──────────────────────
    function pmLayoutComic(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, effect) {
      var totalH = lines.length * lineH + padV * 2;
      var startY = (PM_H - totalH) / 2 + padV + fontSize;
      lines.forEach(function(segs, li) {
        var y      = startY + li * lineH;
        var sz     = segs.some(function(s){ return s.big; }) ? accentSize : fontSize;
        ctx.font   = '900 ' + sz + 'px ' + font;
        var totalW = pmLineWidth(ctx, segs, fontSize, accentSize, font);
        var bx     = (PM_W - totalW) / 2 - 18;
        var bw     = totalW + 36;
        var bh     = sz * 1.35;
        var by     = y - sz * 0.85;
        var r      = 10;
        // Fond noir arrondi
        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,0.88)';
        ctx.beginPath();
        ctx.moveTo(bx + r, by);
        ctx.lineTo(bx + bw - r, by);
        ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + r);
        ctx.lineTo(bx + bw, by + bh - r);
        ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - r, by + bh);
        ctx.lineTo(bx + r, by + bh);
        ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - r);
        ctx.lineTo(bx, by + r);
        ctx.quadraticCurveTo(bx, by, bx + r, by);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        // Texte
        var x = (PM_W - totalW) / 2;
        segs.forEach(function(s) {
          var fsz = s.big ? accentSize : fontSize;
          ctx.font = '900 ' + fsz + 'px ' + font;
          // Outline accent épais
          ctx.lineWidth   = Math.max(6, fsz * 0.1);
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = s.accent ? colorAcc : 'rgba(255,255,255,0.1)';
          ctx.strokeText(s.t, x, y);
          ctx.fillStyle   = s.accent ? colorAcc : '#ffffff';
          ctx.fillText(s.t, x, y);
          x += ctx.measureText(s.t).width;
        });
      });
    }

    // ── Layout BLOC BLANC : rectangle blanc opaque centré, style magazine ─────────
    function pmLayoutBloc(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, effect, opacity) {
      var totalH  = lines.length * lineH;
      var blocH   = totalH + padV * 3;
      var blocY   = (PM_H - blocH) / 2;
      var padLR   = 40;
      // Calculer largeur max des lignes
      var maxW = 0;
      lines.forEach(function(segs) {
        var w = pmLineWidth(ctx, segs, fontSize, accentSize, font);
        if (w > maxW) maxW = w;
      });
      var blocW = Math.min(PM_W, maxW + padLR * 2);
      var blocX = (PM_W - blocW) / 2;
      // Rectangle blanc
      ctx.save();
      ctx.fillStyle = 'rgba(255,255,255,' + Math.max(opacity, 0.88) + ')';
      ctx.beginPath();
      var r = 14;
      ctx.moveTo(blocX + r, blocY);
      ctx.lineTo(blocX + blocW - r, blocY);
      ctx.quadraticCurveTo(blocX + blocW, blocY, blocX + blocW, blocY + r);
      ctx.lineTo(blocX + blocW, blocY + blocH - r);
      ctx.quadraticCurveTo(blocX + blocW, blocY + blocH, blocX + blocW - r, blocY + blocH);
      ctx.lineTo(blocX + r, blocY + blocH);
      ctx.quadraticCurveTo(blocX, blocY + blocH, blocX, blocY + blocH - r);
      ctx.lineTo(blocX, blocY + r);
      ctx.quadraticCurveTo(blocX, blocY, blocX + r, blocY);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      // Texte foncé sur fond blanc
      var startY = blocY + padV * 1.5 + fontSize;
      lines.forEach(function(segs, li) {
        var y      = startY + li * lineH;
        var totalW = pmLineWidth(ctx, segs, fontSize, accentSize, font);
        var x      = (PM_W - totalW) / 2;
        segs.forEach(function(s) {
          var fsz = s.big ? accentSize : fontSize;
          ctx.font      = '900 ' + fsz + 'px ' + font;
          ctx.fillStyle = s.accent ? colorAcc : '#1a1a1a';
          ctx.fillText(s.t, x, y);
          x += ctx.measureText(s.t).width;
        });
      });
    }

    // ── Layout SHADOW : texte + ombre portée, sans overlay ────────────────────────
    function pmLayoutShadow(ctx, lines, fontSize, accentSize, lineH, padV, font, colorMain, colorAcc, effect) {
      var totalH = lines.length * lineH;
      var startY = (PM_H - totalH) / 2 + fontSize;
      lines.forEach(function(segs, li) {
        var y      = startY + li * lineH;
        var totalW = pmLineWidth(ctx, segs, fontSize, accentSize, font);
        var x      = (PM_W - totalW) / 2;
        segs.forEach(function(s) {
          var fsz = s.big ? accentSize : fontSize;
          ctx.font = '900 ' + fsz + 'px ' + font;
          // Ombre portée épaisse
          ctx.save();
          ctx.shadowColor   = 'rgba(0,0,0,0.85)';
          ctx.shadowBlur    = Math.round(fsz * 0.15);
          ctx.shadowOffsetX = Math.round(fsz * 0.06);
          ctx.shadowOffsetY = Math.round(fsz * 0.06);
          // Deuxième passe ombre pour densifier
          ctx.fillStyle = 'rgba(0,0,0,0.5)';
          ctx.fillText(s.t, x + Math.round(fsz*0.05), y + Math.round(fsz*0.05));
          ctx.restore();
          // Texte principal
          ctx.fillStyle = s.accent ? colorAcc : colorMain;
          ctx.fillText(s.t, x, y);
          x += ctx.measureText(s.t).width;
        });
      });
    }

    // ══════════════════════════════════════════════════════════════════════════════
    // EFFETS TYPOGRAPHIQUES
    // ══════════════════════════════════════════════════════════════════════════════
    function pmDrawEffect(ctx, text, x, y, fontSize, color, accent, effect) {
      ctx.save();
      switch (effect) {

        case 'stroke': // Contour gras classique — lisible sur tout fond
          ctx.lineWidth   = Math.max(6, fontSize * 0.12);
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = 'rgba(0,0,0,0.8)';
          ctx.strokeText(text, x, y);
          ctx.fillStyle   = color;
          ctx.fillText(text, x, y);
          break;

        case 'neon': // Lueur néon — effet club / tendance
          // Halo large
          ctx.shadowColor = accent;
          ctx.shadowBlur  = fontSize * 0.7;
          ctx.fillStyle   = accent;
          ctx.globalAlpha = 0.35;
          ctx.fillText(text, x, y);
          ctx.globalAlpha = 1;
          // Halo moyen
          ctx.shadowBlur  = fontSize * 0.3;
          ctx.fillStyle   = '#fff';
          ctx.fillText(text, x, y);
          // Core net
          ctx.shadowBlur  = fontSize * 0.08;
          ctx.fillStyle   = color;
          ctx.fillText(text, x, y);
          ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0;
          break;

        case 'shadow3d': // Ombre portée 3D empilée
          var depth = Math.round(fontSize * 0.08);
          for (var d = depth; d >= 1; d--) {
            var a = 0.08 + (depth - d) * 0.06;
            ctx.fillStyle = 'rgba(0,0,0,' + Math.min(a, 0.55) + ')';
            ctx.fillText(text, x + d, y + d);
          }
          // Stroke fin
          ctx.lineWidth   = 2;
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = 'rgba(0,0,0,0.45)';
          ctx.strokeText(text, x, y);
          ctx.fillStyle   = color;
          ctx.fillText(text, x, y);
          // Reflet léger en haut
          ctx.fillStyle   = 'rgba(255,255,255,0.18)';
          ctx.fillText(text, x, y - 2);
          break;

        case 'outline': // Outline couleur accent + intérieur blanc — style magazine
          // Outline épais accent
          ctx.lineWidth   = Math.max(10, fontSize * 0.16);
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = accent;
          ctx.strokeText(text, x, y);
          // Outline fin noir pour séparer
          ctx.lineWidth   = Math.max(3, fontSize * 0.04);
          ctx.strokeStyle = 'rgba(0,0,0,0.5)';
          ctx.strokeText(text, x, y);
          // Fill blanc
          ctx.fillStyle   = '#ffffff';
          ctx.fillText(text, x, y);
          break;

        case 'glitch': // Décalage RGB — style streetwear / digital
          // Couche rouge
          ctx.globalAlpha = 0.7;
          ctx.fillStyle   = '#ff0044';
          ctx.fillText(text, x - Math.round(fontSize*0.045), y + 2);
          // Couche cyan
          ctx.fillStyle   = '#00ffe0';
          ctx.fillText(text, x + Math.round(fontSize*0.045), y - 2);
          ctx.globalAlpha = 1;
          // Core stroke + fill
          ctx.lineWidth   = Math.max(4, fontSize * 0.07);
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = 'rgba(0,0,0,0.7)';
          ctx.strokeText(text, x, y);
          ctx.fillStyle   = color;
          ctx.fillText(text, x, y);
          // Barre de scan horizontale
          ctx.save();
          ctx.globalAlpha = 0.13;
          ctx.fillStyle   = '#fff';
          var tw = ctx.measureText(text).width;
          ctx.fillRect(x - 4, y - fontSize * 0.55, tw + 8, fontSize * 0.2);
          ctx.fillRect(x - 4, y + fontSize * 0.05,  tw + 8, fontSize * 0.12);
          ctx.restore();
          break;

        case 'retro': // Double contour rétro — style années 80 / sticker
          // Ombre portée bas-droite épaisse
          ctx.fillStyle   = 'rgba(0,0,0,0.9)';
          ctx.fillText(text, x + Math.round(fontSize*0.06), y + Math.round(fontSize*0.06));
          // Outline accent très épais
          ctx.lineWidth   = Math.max(12, fontSize * 0.18);
          ctx.lineJoin    = 'round';
          ctx.strokeStyle = accent;
          ctx.strokeText(text, x, y);
          // Outline noir fin
          ctx.lineWidth   = Math.max(4, fontSize * 0.05);
          ctx.strokeStyle = '#000';
          ctx.strokeText(text, x, y);
          // Fill couleur principale
          ctx.fillStyle   = color;
          ctx.fillText(text, x, y);
          // Reflet diagonal
          ctx.save();
          ctx.globalAlpha = 0.22;
          var tw2 = ctx.measureText(text).width;
          var grad = ctx.createLinearGradient(x, y-fontSize, x+tw2, y);
          grad.addColorStop(0, '#fff');
          grad.addColorStop(1, 'transparent');
          ctx.fillStyle = grad;
          ctx.fillText(text, x, y);
          ctx.restore();
          break;

        default:
          ctx.fillStyle = color;
          ctx.fillText(text, x, y);
      }
      ctx.restore();
    }

    // ── Parse *accent*, /grand/, */grand+couleur/* ───────────────────────────────
    function pmParseTitle(raw) {
      var segs = [];
      // Tokeniser : */mot/* | *mot* | /mot/ | texte normal
      var tokens = raw.split(/(\*\/[^\/]+\/\*|\/[^\/]+\/|\*[^*]+\*)/);
      tokens.forEach(function(p) {
        if (!p) return;
        if (p.startsWith('*/') && p.endsWith('/*')) {
          // Couleur accent + grande taille
          segs.push({ t: p.slice(2,-2).toUpperCase(), accent: true, big: true });
        } else if (p.startsWith('*') && p.endsWith('*')) {
          // Couleur accent seulement
          segs.push({ t: p.slice(1,-1).toUpperCase(), accent: true, big: false });
        } else if (p.startsWith('/') && p.endsWith('/')) {
          // Grande taille seulement
          segs.push({ t: p.slice(1,-1).toUpperCase(), accent: false, big: true });
        } else {
          p.split('\n').forEach(function(line, i) {
            if (i > 0) segs.push({ t: '\n', accent: false, big: false });
            if (line)  segs.push({ t: line.toUpperCase(), accent: false, big: false });
          });
        }
      });
      return segs;
    }

    // ── Word-wrap segments ─────────────────────────────────────────────────────
    function pmWrapSegments(ctx, segs, maxW, fontSize, accentSize, font) {
      var words = [];
      segs.forEach(function(s) {
        if (s.t === '\n') { words.push({ t: '\n', accent: false, big: false }); return; }
        s.t.split(' ').forEach(function(w, i) {
          if (i > 0) words.push({ t: ' ', accent: false, big: false });
          words.push({ t: w, accent: s.accent, big: s.big });
        });
      });
      var lines = [[]], lineW = 0;
      words.forEach(function(w) {
        if (w.t === '\n') { lines.push([]); lineW = 0; return; }
        ctx.font = '900 ' + (w.big ? accentSize : fontSize) + 'px ' + font;
        var wW = ctx.measureText(w.t).width;
        if (lineW + wW > maxW && lines[lines.length-1].length) {
          lines.push([]); lineW = 0;
          if (w.t.trim() === '') return;
        }
        lines[lines.length-1].push(w); lineW += wW;
      });
      while (lines.length > 1 && !lines[lines.length-1].length) lines.pop();
      return lines;
    }

    // ── GitHub upload ──────────────────────────────────────────────────────────
    async function pmGithubUpload(token, user, repo, filename, b64) {
      var url = 'https://api.github.com/repos/' + user + '/' + repo + '/contents/pins/' + filename;
      var sha = null;
      try {
        var chk = await fetch(url, { headers: { 'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json' }});
        if (chk.ok) { var d = await chk.json(); sha = d.sha; }
      } catch(e) {}
      var body = { message: 'pin: '+filename, content: b64 };
      if (sha) body.sha = sha;
      var resp = await fetch(url, {
        method: 'PUT',
        headers: { 'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Content-Type':'application/json' },
        body: JSON.stringify(body)
      });
      if (!resp.ok) throw new Error('GitHub '+resp.status+': '+await resp.text());
      return (await resp.json()).content.download_url;
    }

    function pmBuildUtm(dest, n) {
      try {
        var u = new URL(dest);
        u.searchParams.set('utm_source','pinterest');
        u.searchParams.set('utm_medium','bulk');
        u.searchParams.set('utm_content','pin'+String(n).padStart(2,'0'));
        return u.toString();
      } catch(e) { return dest; }
    }

    function pmCsvEsc(s) { return '"' + (s||'').replace(/"/g,'""') + '"'; }

    // ── Export GitHub + CSV ────────────────────────────────────────────────────
    var _el_pmExportBtn = document.getElementById('pmExportBtn'); if (_el_pmExportBtn) _el_pmExportBtn.addEventListener('click', async function() {
      var grid = document.getElementById('pmGrid');
      if (!grid) { showToast('Valide d\'abord ta sélection'); return; }
      var canvases = Array.from(grid.querySelectorAll('canvas'));
      if (!canvases.length) { showToast('Aucune image à exporter'); return; }

      var token   = document.getElementById('pmGhToken').value.trim();
      var user    = document.getElementById('pmGhUser').value.trim();
      var repo    = document.getElementById('pmGhRepo').value.trim();
      var board   = document.getElementById('pmBoard').value.trim();
      var desc    = document.getElementById('pmDescription').value.trim();
      var hashtags= document.getElementById('pmHashtags').value.trim();
      var pubDate = document.getElementById('pmPublishDate').value.trim();
      var useUtm  = document.getElementById('pmUtm').checked;

      // Description complète = description + hashtags
      var fullDesc = (desc + (hashtags ? ' ' + hashtags : '')).trim();

      // Validation selon le mode
      if (!token) { showToast('⚠ Token GitHub manquant'); return; }
      if (!board) { showToast('⚠ Board Pinterest manquant'); return; }

      var dest = '';
      if (pmExportMode === 'blog') {
        dest = document.getElementById('pmDestUrl').value.trim();
        if (!dest) { showToast("⚠ URL de l'article manquante"); return; }
        dest = dest.startsWith('http') ? dest : 'https://' + dest;
      } else {
        // Mode Amazon
        var affTag  = document.getElementById('pmAffTag').value;
        var affLien = document.getElementById('pmAffLien').value.trim();
        if (!affLien) { showToast('⚠ Lien Amazon manquant'); return; }
        if (!fullDesc.includes('#ad')) { showToast('⚠ La description doit contenir #ad'); return; }
        // Construire l'URL Amazon avec le tag
        try {
          var u = new URL(affLien.startsWith('http') ? affLien : 'https://' + affLien);
          u.searchParams.set('tag', affTag);
          dest = u.toString();
        } catch(e) { dest = affLien; }
      }

      var prog  = document.getElementById('pmProgress');
      var bar   = document.getElementById('pmProgressBar');
      var lbl   = document.getElementById('pmProgressLabel');
      prog.style.display = ''; bar.style.width = '0%';

      var hdr = ['Title','Media URL','Pinterest board','Description','Link'];
      if (pubDate) hdr.push('Publish date');
      var rows      = [hdr.join(',')];
      var titleBase = document.getElementById('pmTitle').value.trim() || 'Pin';
      var total     = canvases.length;
      var errors    = 0;

      for (var i = 0; i < total; i++) {
        var n      = i + 1;
        var canvas = canvases[i];
        var origIdx= parseInt(canvas.dataset.origIdx);
        lbl.textContent = n + '/' + total + ' — upload en cours…';
        bar.style.width = Math.round(i/total*100) + '%';

        pmRenderOne(canvas, pmAllImages[origIdx], i);
        await new Promise(function(r){ setTimeout(r, 120); });

        try {
          var b64      = canvas.toDataURL('image/jpeg', 0.93).split(',')[1];
          var filename = 'pin_' + Date.now() + '_' + n + '.jpg';
          var mediaUrl = await pmGithubUpload(token, user, repo, filename, b64);
          // Nettoyer le titre pour le CSV : retirer *astérisques* et sauts de ligne
          var cleanTitle = titleBase
            .replace(/\*\/([^\/]+)\/\*/g, '$1') // */mot/* → mot
            .replace(/\/([^\/]+)\//g, '$1')       // /mot/ → mot
            .replace(/\*([^*]+)\*/g, '$1')          // *mot* → mot
            .replace(/[\r\n]+/g, ' ')               // sauts de ligne → espace
            .replace(/\s+/g, ' ')                    // espaces multiples → un seul
            .trim();
          var pinTitle = total > 1 ? cleanTitle + ' (' + n + ')' : cleanTitle;
          // Lien final (dest déjà validé + https + tag Amazon si besoin)
          var link = useUtm ? pmBuildUtm(dest, n) : dest;
          var row      = [pmCsvEsc(pinTitle), pmCsvEsc(mediaUrl), pmCsvEsc(board), pmCsvEsc(fullDesc), pmCsvEsc(link)];
          if (pubDate) row.push(pmCsvEsc(pubDate));
          rows.push(row.join(','));
        } catch(e) { errors++; showToast('Erreur pin ' + n + ' : ' + e.message); }
      }

      bar.style.width = '100%';
      lbl.textContent = '✅ ' + (total-errors) + ' images uploadées — génération du CSV…';

      var blob = new Blob(['\uFEFF' + rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
      var url2 = URL.createObjectURL(blob);
      var a    = document.createElement('a');
      a.href = url2; a.download = 'pinterest-export-' + ts() + '.csv';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      URL.revokeObjectURL(url2);
      setTimeout(function(){ prog.style.display='none'; }, 3000);
      showToast('✅ CSV généré — ' + (total-errors) + ' pins' + (errors?' ('+errors+' erreurs)':''));
    });

    // ── Vider pins/ GitHub ─────────────────────────────────────────────────────
    var _el_pmCleanGithub = document.getElementById('pmCleanGithub'); if (_el_pmCleanGithub) _el_pmCleanGithub.addEventListener('click', async function() {
      var token = document.getElementById('pmGhToken').value.trim();
      var user  = document.getElementById('pmGhUser').value.trim();
      var repo  = document.getElementById('pmGhRepo').value.trim();
      if (!token) { showToast('⚠ Token GitHub manquant'); return; }
      if (!confirm('Supprimer tous les fichiers dans pins/ sur GitHub ?')) return;
      try {
        var url  = 'https://api.github.com/repos/' + user + '/' + repo + '/contents/pins';
        var resp = await fetch(url, { headers: { 'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json' }});
        if (!resp.ok) throw new Error('GitHub ' + resp.status);
        var files = await resp.json();
        if (!Array.isArray(files) || !files.length) { showToast('Dossier pins/ déjà vide'); return; }
        var deleted = 0;
        for (var f of files) {
          await fetch('https://api.github.com/repos/' + user + '/' + repo + '/contents/' + f.path, {
            method: 'DELETE',
            headers: { 'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Content-Type':'application/json' },
            body: JSON.stringify({ message: 'clean pins/', sha: f.sha })
          });
          deleted++;
        }
        showToast('✅ ' + deleted + ' fichier(s) supprimé(s) de GitHub');
      } catch(e) { showToast('Erreur : ' + e.message); }
    });

    // ── Parse ZIP ─────────────────────────────────────────────────────────────
    function pmParseZip(bytes) {
      var images = [];
      try {
        var view = new DataView(bytes.buffer || bytes);
        var i = 0;
        while (i < bytes.length - 4) {
          if (view.getUint32(i, true) !== 0x04034b50) { i++; continue; }
          var fnLen    = view.getUint16(i+26, true);
          var extraLen = view.getUint16(i+28, true);
          var fn = '';
          for (var j = 0; j < fnLen; j++) fn += String.fromCharCode(bytes[i+30+j]);
          var ext = fn.split('.').pop().toLowerCase();
          if (['jpg','jpeg','png','webp'].includes(ext)) {
            var compMethod = view.getUint16(i+8, true);
            var compSize   = view.getUint32(i+18, true);
            var dataStart  = i + 30 + fnLen + extraLen;
            if (compMethod === 0) {
              var fileBytes = bytes.slice(dataStart, dataStart + compSize);
              var mime = ext==='png'?'image/png':ext==='webp'?'image/webp':'image/jpeg';
              images.push({ name: fn.split('/').pop(), dataUrl: 'data:'+mime+';base64,'+pmBytesToB64(fileBytes) });
            }
          }
          i += 30 + fnLen + extraLen + view.getUint32(i+18, true);
        }
      } catch(e) { console.warn('pmParseZip', e); }
      return images;
    }

    function pmBytesToB64(bytes) {
      var bin = '', chunk = 8192;
      for (var i = 0; i < bytes.length; i += chunk)
        bin += String.fromCharCode.apply(null, bytes.subarray(i, i+chunk));
      return btoa(bin);
    }

  } // end initPinMaker

  // Init — reset filtres pour éviter état résiduel entre sessions
  (function() {
    var rf = document.getElementById('ratioFilter');
    var pf = document.getElementById('periodFilter');
    var ms = document.getElementById('minSaves');
    var mv = document.getElementById('minViral');
    var ho = document.getElementById('hotOnly');
    var eo = document.getElementById('earlyOnly');
    if (rf) rf.value = 'all';
    if (pf) pf.value = 'all';
    if (ms) ms.value = '';
    if (mv) mv.value = '';
    if (ho) ho.checked = false;
    if (eo) eo.checked = false;
  })();

  loadPins();

})();
