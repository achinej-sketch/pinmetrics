// PinMetrics Pro - Popup Script v2.6

document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isPinterest = tab?.url?.includes('pinterest');

  updateCount();
  updateToggle();
  updateTextStats();
  setInterval(updateCount, 2000);

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'statsUpdate') {
      if (msg.cached !== undefined)
        document.getElementById('cachedCount').textContent = msg.cached;
      const box = document.getElementById('collectingBox');
      if (msg.collecting > 0) {
        box.style.display = '';
        document.getElementById('collectingCount').textContent = msg.collecting;
      } else { box.style.display = 'none'; }
    }
    if (msg.action === 'autoScrollStopped') {
      setScrollUI(false);
      showFeedback('Auto-scroll terminé — ' + (msg.total||0) + ' pins collectés');
      updateCount();
    }
  });

  document.getElementById('toggleStats').addEventListener('change', async (e) => {
    if (!tab?.id) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { action: e.target.checked ? 'showStats' : 'hideStats' });
      showFeedback(e.target.checked ? 'Stats affichées' : 'Stats masquées');
    } catch(err) {
      showFeedback("Rafraîchis la page Pinterest d'abord");
      e.target.checked = !e.target.checked;
    }
  });

  document.getElementById('analyticsBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('analytics.html') });
  });

  document.getElementById('resetBtn').addEventListener('click', async () => {
    if (!tab?.id) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'resetCache' });
      document.getElementById('cachedCount').textContent = '0';
      showFeedback('Cache vidé — rescan en cours…');
    } catch(err) { showFeedback("Rafraîchis la page Pinterest d'abord"); }
  });

  document.getElementById('startScrollBtn').addEventListener('click', async () => {
    if (!tab?.id) return;
    if (!isPinterest) { showFeedback("Ouvre Pinterest d'abord"); return; }
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'startAutoScroll', delay: 3500, maxScrolls: 80 });
      setScrollUI(true);
      showFeedback('Auto-scroll démarré — collecte en cours…');
    } catch(err) { showFeedback("Rafraîchis la page Pinterest d'abord"); }
  });

  document.getElementById('stopScrollBtn').addEventListener('click', async () => {
    if (!tab?.id) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'stopAutoScroll' });
      setScrollUI(false);
      showFeedback('Auto-scroll arrêté');
    } catch(err) {}
  });

  // ── Analyse texte ────────────────────────────────────────────────────────────
  document.getElementById('analyzeBtn').addEventListener('click', async () => {
    const btn    = document.getElementById('analyzeBtn');
    const status = document.getElementById('analyzeStatus');
    btn.disabled = true;
    btn.textContent = '⏳ Analyse en cours…';
    try {
      const items   = await chrome.storage.local.get(null);
      const pinKeys = Object.keys(items).filter(k => k.startsWith('pin_'));
      // Re-analyser tous les pins avec une imageUrl (force la correction)
      const todo    = pinKeys.filter(k => items[k] && items[k].imageUrl);
      const total   = todo.length;
      if (total === 0) {
        status.textContent = 'Tous analysés';
        btn.disabled = false; btn.textContent = '🔄 Re-analyser';
        updateTextStats(); return;
      }
      let done = 0;
      for (let i = 0; i < todo.length; i += 5) {
        const batch = todo.slice(i, i + 5);
        await Promise.all(batch.map(async (key) => {
          const pin = items[key];
          try { pin.hasText = await analyzeImage(pin.imageUrl); await chrome.storage.local.set({ [key]: pin }); } catch(e) {}
          status.textContent = (++done) + '/' + total + ' analysés…';
        }));
      }
      status.textContent = 'Terminé — ' + total + ' pins analysés';
      btn.textContent = '🔄 Re-analyser'; btn.disabled = false;
      updateTextStats();
    } catch(e) {
      status.textContent = 'Erreur — réessaie';
      btn.disabled = false; btn.textContent = '🔍 Lancer l\'analyse';
    }
  });

  // ── Détection texte via service worker (OffscreenCanvas, sans blocage CORS) ──
  function analyzeImage(url) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve('unknown'), 10000);
      chrome.runtime.sendMessage({ action: 'analyzeImageForText', url }, (resp) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError || !resp) { resolve('unknown'); return; }
        resolve(resp.result || 'unknown');
      });
    });
  }

  // ── Helpers ──────────────────────────────────────────────────────────────────
  async function updateCount() {
    if (tab?.id) {
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { action: 'getCacheSize' });
        if (r?.cacheSize !== undefined) { document.getElementById('cachedCount').textContent = r.cacheSize; return; }
      } catch(e) {}
    }
    try {
      const items  = await chrome.storage.local.get(null);
      const newIds = new Set(Object.keys(items).filter(k => k.startsWith('pin_')).map(k => k.replace('pin_','')));
      const oldIds = items.pinsData ? Object.keys(items.pinsData).filter(id => !newIds.has(id)) : [];
      document.getElementById('cachedCount').textContent = newIds.size + oldIds.length;
    } catch(e) {}
  }

  async function updateToggle() {
    if (!tab?.id) return;
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { action: 'getState' });
      document.getElementById('toggleStats').checked = r?.isActive !== false;
      if (r?.autoScroll) setScrollUI(true);
    } catch(e) {}
  }

  async function updateTextStats() {
    try {
      const items = await chrome.storage.local.get(null);
      const pins  = Object.keys(items).filter(k => k.startsWith('pin_')).map(k => items[k]);
      const tc = pins.filter(p => p?.hasText === 'text').length;
      const ic = pins.filter(p => p?.hasText === 'image').length;
      document.getElementById('tfTextCount').textContent  = tc;
      document.getElementById('tfImageCount').textContent = ic;
      const el = document.getElementById('textFilterResults');
      if (el) el.style.display = (tc + ic) > 0 ? '' : 'none';
    } catch(e) {}
  }

  function setScrollUI(active) {
    document.getElementById('startScrollBtn').style.display = active ? 'none' : '';
    document.getElementById('stopScrollBtn').style.display  = active ? ''     : 'none';
    document.getElementById('scrollStatus').textContent     = active ? '🔄 En cours…' : 'Inactif';
  }

  function showFeedback(msg) {
    const el = document.getElementById('feedback');
    el.textContent = msg; el.style.display = '';
    setTimeout(() => el.style.display = 'none', 3000);
  }
});
