// PinMetrics Pro - Content Script v2.1 (fixes collection freeze)

(function() {
  'use strict';
  if (window.__pmLoaded) return;
  window.__pmLoaded = true;

  window.PinterestStats = {
    dataCache: new Map(),
    isActive: true,
    isUpdating: false,
    autoScrollActive: false,
    autoScrollTimer: null,
    autoScrollCount: 0,
    collectingCount: 0,
    _pendingPins: new Set(),
    _observer: null,
    _scanDebounce: null,

    async start() {
      await this.loadCache();
      await this.waitForHydration();
      this.scanForPins();
      this.startObserver();
      this._watchSoftNav();
    },

    async waitForHydration() {
      return new Promise(r => {
        const check = () => document.querySelectorAll('[data-test-pin-id]').length > 0 ? r() : setTimeout(check, 100);
        setTimeout(check, 1500);
      });
    },

    async loadCache() {
      try {
        const items = await chrome.storage.local.get(null);
        let n = 0;
        for (const [k, v] of Object.entries(items)) {
          if (k.startsWith('pin_') && v && v.id) { this.dataCache.set(v.id, v); n++; }
        }
        if (items.pinsData && typeof items.pinsData === 'object') {
          const toMigrate = {};
          for (const [pinId, v] of Object.entries(items.pinsData)) {
            if (v && !this.dataCache.has(pinId)) {
              const normalized = {
                id: v.id || pinId, title: v.title || '', description: '',
                saves: v.saves || 0, comments: 0, shares: 0, reactions: 0,
                createdAt: null, viralScore: 0, isHot: false, isEarly: false, aspectRatio: null,
                created: v.created || '', imageUrl: v.imageUrl || '', imageUrlOrig: v.imageUrl || '',
                pinUrl: `https://www.pinterest.com/pin/${pinId}/`,
                boardName: v.boardName || '', boardUrl: v.boardUrl || '',
                pinner: '', pinnerUrl: '', bookmarked: v.bookmarked || false,
                timestamp: v.timestamp || Date.now()
              };
              this.dataCache.set(pinId, normalized);
              toMigrate[`pin_${pinId}`] = normalized;
              n++;
            }
          }
          if (Object.keys(toMigrate).length > 0) chrome.storage.local.set(toMigrate).catch(()=>{});
        }
        if (n) console.log(`PinMetrics: ${n} pins charges`);
      } catch(e) {}
    },

    scanForPins() {
      if (!this.isActive) return;

      const m = location.pathname.match(/\/pin\/(\d+)/);
      if (m) {
        const id = m[1];
        const el = document.querySelector('[data-test-id="closeup-image"]')
                    ?.closest('[data-test-id="visual-content-container"]')
                  || document.querySelector('[data-test-id="pin-closeup-image"]');
        if (el && !el.querySelector('.pm-overlay,.pm-loader')) {
          this.dataCache.has(id) ? this.showStats(el, this.dataCache.get(id)) : this.processPin(id, el);
        }
      }

      document.querySelectorAll('[data-test-pin-id]').forEach(el => {
        const id = el.getAttribute('data-test-pin-id');
        if (!id) return;
        if (el.querySelector('.pm-overlay,.pm-loader')) return;
        if (this._pendingPins.has(id)) return;
        if (this.dataCache.has(id)) {
          this.showStats(el, this.dataCache.get(id));
        } else {
          this.processPin(id, el);
        }
      });
    },

    startObserver() {
      if (this._observer) { this._observer.disconnect(); this._observer = null; }
      const target = document.querySelector('[role="list"]') || document.body;
      this._observer = new MutationObserver(muts => {
        const changed = muts.some(m =>
          [...m.addedNodes].some(n => n.nodeType === 1 &&
            (n.hasAttribute?.('data-test-pin-id') || n.querySelector?.('[data-test-pin-id]')))
          || [...m.removedNodes].some(n => n.classList?.contains('pm-overlay'))
        );
        if (changed) {
          clearTimeout(this._scanDebounce);
          this._scanDebounce = setTimeout(() => this.scanForPins(), 300);
        }
      });
      this._observer.observe(target, { childList: true, subtree: true });
    },

    _watchSoftNav() {
      let lastUrl = location.href;
      const check = () => {
        if (location.href !== lastUrl) {
          lastUrl = location.href;
          setTimeout(() => { this.startObserver(); this.scanForPins(); }, 800);
        }
      };
      const _pushState = history.pushState.bind(history);
      history.pushState = function(...args) { _pushState(...args); check(); };
      window.addEventListener('popstate', check);
      setInterval(check, 2000);
    },

    async processPin(pinId, el) {
      if (this._pendingPins.has(pinId)) return;
      this._pendingPins.add(pinId);
      this.showLoader(el);
      this.collectingCount++;
      this.notifyPopup();
      try {
        const data = await this.fetchWithRetry(pinId);
        this.removeLoader(el);
        this.collectingCount = Math.max(0, this.collectingCount - 1);
        this._pendingPins.delete(pinId);
        this.notifyPopup();
        if (data) {
          this.dataCache.set(pinId, data);
          chrome.storage.local.set({ [`pin_${pinId}`]: { ...data, timestamp: Date.now() } }).catch(()=>{});
          this.showStats(el, data);
          // Lancer la détection texte en arrière-plan (sans bloquer)
          if (data.imageUrl && typeof window.PinTextDetector !== 'undefined') {
            window.PinTextDetector.detect(data.imageUrl, pinId).then(hasText => {
              data.hasText = hasText;
              this.dataCache.set(pinId, data);
            }).catch(()=>{});
          }
        } else {
          this.showError(el, pinId);
        }
      } catch(e) {
        this.removeLoader(el);
        this.collectingCount = Math.max(0, this.collectingCount - 1);
        this._pendingPins.delete(pinId);
        this.notifyPopup();
        this.showError(el, pinId);
      }
    },

    async fetchWithRetry(pinId, max=3) {
      for (let i=0; i<max; i++) {
        try {
          const d = await this.fetchPinData(pinId);
          if (d) return d;
          if (i < max-1) await this.delay(Math.pow(2,i)*500);
        } catch(e) {
          if (i < max-1) await this.delay(Math.pow(2,i)*500);
        }
      }
      return null;
    },

    async fetchPinData(pinId) {
      try {
        const base = `${location.protocol}//${location.hostname}/resource/PinResource/get/`;
        const params = new URLSearchParams({
          _: Date.now(),
          data: JSON.stringify({ options: { id: pinId, field_set_key: 'detailed', fetch_visual_search_objects: true }, context: {} }),
          source_url: '/homefeed/'
        });
        const r = await fetch(`${base}?${params}`, {
          headers: { Accept: 'application/json', 'x-pinterest-pws-handler': 'www/homefeed.js' },
          credentials: 'include'
        });
        if (!r.ok) return this.domFallback(pinId);
        const j = await r.json();
        const pin = j?.resource_response?.data;
        if (!pin) return this.domFallback(pinId);

        const saves     = pin.repin_count || pin.aggregated_pin_data?.aggregated_stats?.saves || 0;
        const comments  = pin.aggregated_pin_data?.comment_count || 0;
        const shares    = pin.share_count || 0;
        const reactions = Object.values(pin.reaction_counts || {}).reduce((a,b)=>a+b, 0);
        const createdAt = pin.created_at || null;
        const daysSince = createdAt ? (Date.now()-new Date(createdAt).getTime())/86400000 : 0;
        const viralScore = daysSince>0 ? Math.round(saves/daysSince*10)/10 : 0;
        const isEarly = daysSince<7 && saves>=50;
        const isHot   = viralScore>=20;
        const img = pin.images?.orig || pin.images?.['736x'] || Object.values(pin.images||{})[0];
        const ratio = (img?.width && img?.height) ? img.width/img.height : null;
        const aspectRatio = ratio ? (ratio>1.1?'landscape':ratio<0.9?'portrait':'square') : null;

        return {
          id: pinId, title: pin.title || pin.grid_title || '',
          description: pin.description || '',
          saves, comments, shares, reactions,
          createdAt, viralScore, isEarly, isHot, aspectRatio,
          created: this.timeAgo(createdAt),
          imageUrl: pin.images?.['736x']?.url || pin.images?.orig?.url || '',
          imageUrlOrig: pin.images?.orig?.url || pin.images?.['736x']?.url || '',
          pinUrl: `https://www.pinterest.com/pin/${pinId}/`,
          boardName: pin.board?.name || '',
          boardUrl: pin.board?.url ? `https://www.pinterest.com${pin.board.url}` : '',
          pinner: pin.pinner?.username || '',
          pinnerUrl: pin.pinner?.username ? `https://www.pinterest.com/${pin.pinner.username}/` : '',
          bookmarked: false
        };
      } catch(e) {
        return this.domFallback(pinId);
      }
    },

    domFallback(pinId) {
      const el = document.querySelector(`[data-test-pin-id="${pinId}"]`);
      if (!el) return null;
      const img = el.querySelector('img');
      return {
        id: pinId, title: img?.alt||'', description:'',
        saves:0, comments:0, shares:0, reactions:0,
        createdAt:null, viralScore:0, isEarly:false, isHot:false, aspectRatio:null,
        created:'', imageUrl: img?.src||'', imageUrlOrig: img?.src||'',
        pinUrl:`https://www.pinterest.com/pin/${pinId}/`,
        boardName:'', boardUrl:'', pinner:'', pinnerUrl:'',
        bookmarked:false, fallback:true
      };
    },

    notifyPopup() {
      try { chrome.runtime.sendMessage({ action:'statsUpdate', cached: this.dataCache.size, collecting: this.collectingCount }); } catch(e){}
    },

    startAutoScroll(delay=3500, maxScrolls=60) {
      if (this.autoScrollActive) return;
      this.autoScrollActive = true;
      this.autoScrollCount = 0;
      const tick = () => {
        if (!this.autoScrollActive || this.autoScrollCount >= maxScrolls) {
          this.stopAutoScroll(); return;
        }
        if (this.collectingCount > 8) {
          // Trop de fetches actifs — pause sans compter le scroll
          this.autoScrollTimer = setTimeout(tick, 1000);
          return;
        }
        window.scrollBy({ top: window.innerHeight * 0.85, behavior: 'smooth' });
        this.autoScrollCount++;
        this.notifyPopup();
        this.autoScrollTimer = setTimeout(tick, delay);
      };
      tick();
    },

    stopAutoScroll() {
      this.autoScrollActive = false;
      clearTimeout(this.autoScrollTimer);
      this.autoScrollTimer = null;
      try { chrome.runtime.sendMessage({ action:'autoScrollStopped', total: this.dataCache.size }); } catch(e){}
    },

    delay(ms) { return new Promise(r=>setTimeout(r,ms)); },

    timeAgo(date) {
      if (!date) return '';
      const d = Date.now()-new Date(date).getTime();
      const m=Math.floor(d/6e4), h=Math.floor(d/36e5), dy=Math.floor(d/864e5), mo=Math.floor(dy/30), y=Math.floor(dy/365);
      return y>0?`${y}Y`:mo>0?`${mo}M`:dy>0?`${dy}D`:h>0?`${h}h`:m>0?`${m}m`:'now';
    },

    fmt(n) { if (!n) return '0'; return n>=1e6?(n/1e6).toFixed(1)+'M':n>=1e3?(n/1e3).toFixed(1)+'K':String(n); },

    showLoader(el) {
      if (el.querySelector('.pm-loader')) return;
      const l=document.createElement('div'); l.className='pm-loader';
      l.innerHTML='<div class="pm-spinner"></div>';
      const c=el.querySelector('[data-test-id="pin-visual-wrapper"]')||el;
      c.style.position='relative'; c.appendChild(l);
    },

    removeLoader(el) { el.querySelector('.pm-loader')?.remove(); },

    showError(el, pinId) {
      if (el.querySelector('.pm-overlay')) return;
      const o=document.createElement('div'); o.className='pm-overlay pm-error';
      o.innerHTML=`<div class="pm-stat" data-tooltip="Retry">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/></svg>
        <span class="pm-val">Retry</span></div>`;
      o.addEventListener('click', e=>{ e.stopPropagation(); o.remove(); this._pendingPins.delete(pinId); this.processPin(pinId,el); });
      const c=el.querySelector('[data-test-id="pin-visual-wrapper"]')||el;
      c.style.position='relative'; c.appendChild(o);
    },

    showStats(el, data) {
      if (el.querySelector('.pm-overlay')) return;
      const o=document.createElement('div');
      o.className='pm-overlay'; o.setAttribute('data-pin-id', data.id);
      const isBookmarked = data.bookmarked||false;
      let badge='';
      if (data.isEarly) badge=`<div class="pm-badge pm-early">&#127807; Early</div>`;
      else if (data.isHot) badge=`<div class="pm-badge pm-hot">&#128293; Hot</div>`;
      const ratioMap = { landscape:'&#9632; Wide', portrait:'&#128208; Tall', square:'&#9723; Square' };
      const ratioLabel = data.aspectRatio ? (ratioMap[data.aspectRatio]||'') : '';

      o.innerHTML=`
        ${badge}
        <div class="pm-stat" data-tooltip="Saves">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M19 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg>
          <span class="pm-val">${this.fmt(data.saves)}</span></div>
        ${data.comments>0?`<div class="pm-stat" data-tooltip="Comments">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
          <span class="pm-val">${this.fmt(data.comments)}</span></div>`:''}
        ${data.shares>0?`<div class="pm-stat" data-tooltip="Shares">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"/></svg>
          <span class="pm-val">${this.fmt(data.shares)}</span></div>`:''}
        ${data.reactions>0?`<div class="pm-stat" data-tooltip="Reactions">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          <span class="pm-val">${this.fmt(data.reactions)}</span></div>`:''}
        ${data.viralScore>0?`<div class="pm-stat" data-tooltip="Viral score/jour">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M13.5 2c-5.621 0-10.211 4.443-10.475 10h-3.025l5 6.625 5-6.625h-2.975c.257-3.351 3.06-6 6.475-6 3.584 0 6.5 2.916 6.5 6.5s-2.916 6.5-6.5 6.5c-1.863 0-3.542-.793-4.728-2.053l-2.427 3.216c1.877 1.754 4.389 2.837 7.155 2.837 5.79 0 10.5-4.71 10.5-10.5s-4.71-10.5-10.5-10.5z"/></svg>
          <span class="pm-val">${this.fmt(data.viralScore)}/j</span></div>`:''}
        ${data.created?`<div class="pm-stat" data-tooltip="Cree il y a">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z"/></svg>
          <span class="pm-val">${data.created}</span></div>`:''}
        ${ratioLabel?`<div class="pm-stat" data-tooltip="Format"><span class="pm-val">${ratioLabel}</span></div>`:''}
        ${data.imageUrl?`<div class="pm-stat pm-dl" data-tooltip="Telecharger">
          <a href="${data.imageUrl}" download target="_blank">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
          </a></div>`:''}
        <div class="pm-stat pm-bk ${isBookmarked?'pm-bkd':''}" data-pin-id="${data.id}" data-bookmarked="${isBookmarked}" data-tooltip="${isBookmarked?'Retirer':'Bookmark'}">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="${isBookmarked?'#FFD700':'#fff'}"><path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg>
        </div>`;

      o.querySelector('.pm-bk')?.addEventListener('click', e => {
        e.stopPropagation();
        this.toggleBookmark(data.id, o.querySelector('.pm-bk'));
      });

      const c=el.querySelector('[data-test-id="pin-visual-wrapper"]')||el;
      c.style.position='relative'; c.appendChild(o);
    },

    async toggleBookmark(pinId, btn) {
      const key=`pin_${pinId}`;
      try {
        const r=await chrome.storage.local.get(key);
        const d=r[key]; if (!d) return;
        d.bookmarked=!d.bookmarked;
        this.dataCache.set(pinId, d);
        await chrome.storage.local.set({ [key]: d });
        btn.setAttribute('data-bookmarked', d.bookmarked);
        btn.setAttribute('data-tooltip', d.bookmarked?'Retirer':'Bookmark');
        btn.querySelector('svg').setAttribute('fill', d.bookmarked?'#FFD700':'#fff');
        btn.classList.toggle('pm-bkd', d.bookmarked);
      } catch(e){}
    }
  };

  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    const PS = window.PinterestStats;
    switch(req.action) {
      case 'getCacheSize':   sendResponse({ cacheSize: PS.dataCache.size }); break;
      case 'getState':       sendResponse({ isActive: PS.isActive, autoScroll: PS.autoScrollActive }); break;
      case 'hideStats':      PS.isActive=false; document.querySelectorAll('.pm-overlay,.pm-loader').forEach(e=>e.style.display='none'); sendResponse({success:true}); break;
      case 'showStats':      PS.isActive=true; document.querySelectorAll('.pm-overlay,.pm-loader').forEach(e=>e.style.display=''); PS.scanForPins(); sendResponse({success:true}); break;
      case 'resetCache':
        PS.dataCache.clear();
        PS._pendingPins.clear();
        chrome.storage.local.get(null, items => { chrome.storage.local.remove(Object.keys(items).filter(k=>k.startsWith('pin_'))); });
        document.querySelectorAll('.pm-overlay,.pm-loader').forEach(e=>e.remove());
        PS.scanForPins(); sendResponse({success:true}); break;
      case 'startAutoScroll': PS.startAutoScroll(req.delay||3500, req.maxScrolls||60); sendResponse({success:true}); break;
      case 'stopAutoScroll':  PS.stopAutoScroll(); sendResponse({success:true}); break;
    }
    return true;
  });

  if (document.readyState==='loading') {
    document.addEventListener('DOMContentLoaded', ()=>window.PinterestStats.start());
  } else {
    window.PinterestStats.start();
  }
})();


// ── Text Detection Module v2.6 ────────────────────────────────────────────────
window.PinTextDetector = {
  _cache: new Map(),

  async detect(imageUrl, pinId) {
    if (!imageUrl) return 'unknown';
    if (this._cache.has(pinId)) return this._cache.get(pinId);
    try {
      const result = await this._analyzeImage(imageUrl);
      this._cache.set(pinId, result);
      chrome.storage.local.get(`pin_${pinId}`, (items) => {
        const pin = items[`pin_${pinId}`];
        if (pin) { pin.hasText = result; chrome.storage.local.set({ [`pin_${pinId}`]: pin }).catch(()=>{}); }
      });
      return result;
    } catch(e) { return 'unknown'; }
  },

  _analyzeImage(url) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve('unknown'), 10000);
      chrome.runtime.sendMessage({ action: 'analyzeImageForText', url }, (resp) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError || !resp) { resolve('unknown'); return; }
        resolve(resp.result || 'unknown');
      });
    });
  },

  _detectText(img) {
    const canvas = document.createElement('canvas');
    const scale  = Math.min(1, 200 / Math.max(img.width, img.height));
    const w = Math.round(img.width * scale);
    const h = Math.round(img.height * scale);
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0, w, h);

    const raw  = ctx.getImageData(0, 0, w, h).data;
    const luma = new Float32Array(w * h);
    for (let i = 0; i < w * h; i++)
      luma[i] = 0.299 * raw[i*4] + 0.587 * raw[i*4+1] + 0.114 * raw[i*4+2];

    const EDGE_T  = 50;
    const edgeMap = new Uint8Array(w * h);
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i  = y * w + x;
        const gH = Math.abs(luma[i+1] - luma[i-1]);
        const gV = Math.abs(luma[i+w] - luma[i-w]);
        edgeMap[i] = (gH > EDGE_T || gV > EDGE_T) ? 1 : 0;
      }
    }

    const BAND_H    = Math.max(3, Math.floor(h * 0.12));
    const BAND_STEP = Math.max(1, Math.floor(BAND_H / 2));
    let maxDens = 0;
    for (let sy = 0; sy <= h - BAND_H; sy += BAND_STEP) {
      let count = 0;
      for (let y = sy; y < sy + BAND_H; y++)
        for (let x = 0; x < w; x++) count += edgeMap[y * w + x];
      const d = count / (BAND_H * w);
      if (d > maxDens) maxDens = d;
    }

    return maxDens > 0.16 ? 'text' : 'image';
  }
};
