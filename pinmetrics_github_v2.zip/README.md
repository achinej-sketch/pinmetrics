# PinMetrics

Extension de navigateur (Chrome / Opera) pour analyser les performances Pinterest et détecter les tendances éditoriales.

## Fonctionnalités

- **Analyse des pins** — viralScore, saves, partages, engagement par board
- **Export JSON** — pins triés par viralScore pour la rédaction d'articles
- **Export CSV** — épingles prêtes à uploader en masse sur Pinterest
- **Onglet Trends** — tendances Pinterest en temps réel par pays (FR, US, CA, GB, AU)
- **Export Briefing Claude** 🤖 — exporte les tendances en JSON qualifié par niche CPC pour le briefing éditorial

## Installation (Chrome / Opera Desktop)

1. Télécharge ce repo → **Code → Download ZIP**
2. Dézippe le dossier
3. Ouvre Chrome ou Opera → `chrome://extensions` ou `opera://extensions`
4. Active le **Mode développeur** (toggle en haut à droite)
5. Clique **Charger l'extension non empaquetée**
6. Sélectionne le dossier `pinmetrics_v16`
7. L'icône PinMetrics apparaît dans la barre d'outils

## Mise à jour

1. Dans le terminal : `git pull`
2. Dans Chrome/Opera : `chrome://extensions` → bouton **Actualiser** sur la carte PinMetrics

## Utilisation — Export Briefing Claude

1. Ouvre PinMetrics sur Pinterest
2. Va dans l'onglet **Trends**
3. Sélectionne ton pays + fenêtre temporelle
4. Filtre par **🚀 En hausse** ou **🔥 Top volume**
5. Clique **🤖 Export Briefing Claude**
6. Glisse le JSON dans Claude pour générer le briefing éditorial

## Changelog

### v1.6 — Export Briefing Claude
- Ajout du bouton **🤖 Export Briefing Claude** dans l'onglet Trends
- Détection automatique de la niche CPC (coiffure, mode, beauté, déco, accessoires)
- Tri automatique : rising + hot en premier, puis volume décroissant

### v1.5 — Version de base
- Analyse pins Pinterest
- Export JSON / CSV / ZIP
- Onglet Trends Pinterest natif
